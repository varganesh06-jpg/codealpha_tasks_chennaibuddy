/**
 * Utility to generate optimized image URLs from Unsplash CDN.
 * This ensures high performance, global edge delivery, and automatic format optimization.
 */

export const getCDNImage = (id: string, width: number = 800, height: number = 600) => {
  // Using Unsplash Source API which is backed by their global CDN
  // We use specific parameters for optimization:
  // auto=format: serves WebP/AVIF if supported
  // q=80: high quality but optimized file size
  // fit=crop: ensures the image fits the requested dimensions
  
  // Mapping some common keywords to specific Unsplash IDs for consistency
  const idMap: Record<string, string> = {
    'bus-station': '1544620159-13e9e0947058',
    'chennai-city': '1596176530529-781d9a4fb857',
    'commuter': '1520038410233-7141be7e6f97',
    'map': '1526778548025-fa2f459cd5c1',
    'profile': '1535713875002-d1d0cf377fde',
    'payment': '1556742044-3c52d6e88c62',
    'student': '1523240795612-9a054b0db644',
    'senior': '1581579438747-1dc8d17bbce4',
    'accessibility': '1516714435131-44d6b64dc092',
    'bus-interior': '1544620159-13e9e0947058',
    'ticket': '1540653571600-1742a5599c98',
    'admin': '1507003211169-0a1dd7228f2d',
    'mtc-bus': '1570125909232-eb263c188f7e'
  };

  const unsplashId = idMap[id] || id;
  
  // If it's a direct Unsplash ID
  if (unsplashId.length > 10) {
    return `https://images.unsplash.com/photo-${unsplashId}?auto=format&fit=crop&q=80&w=${width}&h=${height}`;
  }
  
  // Fallback to keyword search if not in map
  return `https://source.unsplash.com/featured/${width}x${height}/?${id}`;
};
