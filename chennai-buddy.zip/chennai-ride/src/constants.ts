import { BusPass, BusArrival, RecentRide, Bus } from './types';

export const MOCK_PASS: BusPass = {
  id: 'PASS-123',
  userId: 'USER-1',
  type: 'Monthly Commuter Pass',
  daysLeft: 12,
  usageCount: 18,
  totalDays: 30,
  expiryDate: 'Oct 31, 2023',
  status: 'Active'
};

export const MOCK_ARRIVALS: BusArrival[] = [
  { route: '23C', destination: 'Besant Nagar', time: '5m', status: 'On Time', crowd: 'Medium', via: 'Mylapore' },
  { route: '102', destination: 'Kelambakkam', time: '12m', status: 'Delayed', crowd: 'High', via: 'OMR' },
  { route: '570', destination: 'Kelambakkam', time: '18m', status: 'On Time', crowd: 'Low', via: 'Guindy' }
];

export const MOCK_RIDES: RecentRide[] = [
  { id: '1', route: '23C', destination: 'Besant Nagar', time: 'Today, 08:45 AM', status: 'Completed' },
  { id: '2', route: '570', destination: 'CMBT', time: 'Yesterday, 06:15 PM', status: 'Completed' },
  { id: '3', route: '102', destination: 'Broadway', time: '22 Oct, 09:30 AM', status: 'Completed' }
];

export const MOCK_BUSES: Bus[] = [
  {
    id: 'BUS-1',
    busNumber: '23C',
    routeName: 'Ayanavaram — Besant Nagar',
    from: 'Ayanavaram',
    to: 'Besant Nagar',
    via: ['Anna Salai', 'Saidapet', 'Mylapore'],
    departureTime: '10:30 AM',
    arrivalTime: '11:45 AM',
    fare: 20,
    seatsAvailable: 15,
    type: 'MTC',
    liveLocation: { lat: 13.0827, lng: 80.2707 }
  },
  {
    id: 'BUS-2',
    busNumber: '102',
    routeName: 'Broadway — Kelambakkam',
    from: 'Broadway',
    to: 'Kelambakkam',
    via: ['Adyar', 'OMR', 'Sipcot'],
    departureTime: '11:00 AM',
    arrivalTime: '12:30 PM',
    fare: 35,
    seatsAvailable: 8,
    type: 'DELUXE',
    liveLocation: { lat: 13.0405, lng: 80.2337 }
  },
  {
    id: 'BUS-3',
    busNumber: '570',
    routeName: 'CMBT — Kelambakkam',
    from: 'CMBT',
    to: 'Kelambakkam',
    via: ['Guindy', 'OMR', 'Thoraipakkam'],
    departureTime: '11:15 AM',
    arrivalTime: '12:45 PM',
    fare: 60,
    seatsAvailable: 22,
    type: 'AC_VOLVO',
    liveLocation: { lat: 13.0674, lng: 80.2376 }
  }
];

export const CHENNAI_STOPS = [
  'T. Nagar', 'Adyar', 'Broadway', 'CMBT', 'Guindy', 'Mylapore', 'Saidapet', 'Tambaram', 'Velachery', 'Anna Nagar', 'Besant Nagar', 'Kelambakkam', 'Ayanavaram'
];
