export type Screen = 
  | 'SPLASH'
  | 'LOGIN'
  | 'OTP_VERIFY'
  | 'DASHBOARD'
  | 'MY_PASS'
  | 'LIVE_TRACKING'
  | 'PROFILE'
  | 'PAYMENT'
  | 'LANGUAGE'
  | 'ARRIVALS'
  | 'SPECIAL_PASSES'
  | 'MY_TICKETS'
  | 'ROUTE_SEARCH'
  | 'AVAILABLE_BUSES'
  | 'BOOKING_SUMMARY'
  | 'ADMIN_DASHBOARD'
  | 'ADMIN_TICKETS'
  | 'ADMIN_BUS_MANAGEMENT'
  | 'ADMIN_FARE_MANAGEMENT';

export interface UserProfile {
  uid: string;
  phoneNumber: string;
  displayName?: string;
  email?: string;
  language: 'en' | 'ta';
  createdAt: string;
}

export interface Bus {
  id: string;
  busNumber: string;
  routeName: string;
  from: string;
  to: string;
  via: string[];
  departureTime: string;
  arrivalTime: string;
  fare: number;
  seatsAvailable: number;
  type: 'MTC' | 'DELUXE' | 'AC_VOLVO';
  liveLocation?: {
    lat: number;
    lng: number;
  };
}

export interface Ticket {
  id: string;
  userId: string;
  busId: string;
  routeId: string;
  passengerName: string;
  busNumber: string;
  routeName: string;
  from: string;
  to: string;
  fare: number;
  travelDate: string;
  travelTime: string;
  status: 'ACTIVE' | 'USED' | 'EXPIRED';
  qrCode: string;
  createdAt: string;
}

export interface BusPass {
  id: string;
  userId: string;
  type: string;
  expiryDate: string;
  daysLeft: number;
  totalDays: number;
  usageCount: number;
  status: 'Active' | 'Expired' | 'Pending';
}

export interface BusArrival {
  route: string;
  destination: string;
  time: string;
  status: string;
  crowd: 'Low' | 'Medium' | 'High';
  via: string;
}

export interface RecentRide {
  id: string;
  route: string;
  destination: string;
  time: string;
  status: string;
}
