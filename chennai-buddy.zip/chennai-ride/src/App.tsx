import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useTranslation } from 'react-i18next';
import { QRCodeSVG } from 'qrcode.react';
import { getCDNImage } from './utils/cdn';
import { 
  Home, 
  Ticket, 
  Map as MapIcon, 
  User, 
  Bell, 
  Cloud, 
  RefreshCw, 
  Plus, 
  ArrowLeft, 
  Info, 
  History, 
  CreditCard, 
  Settings, 
  LogOut, 
  Search, 
  Mic, 
  Navigation, 
  AlertCircle,
  ChevronRight,
  Star,
  MoreHorizontal,
  Bus as BusIcon,
  CheckCircle2,
  ShieldCheck,
  Smartphone,
  LayoutDashboard,
  Users,
  TrendingUp,
  Filter,
  School,
  Accessibility,
  Languages,
  ArrowRight,
  MapPin,
  Calendar,
  Clock,
  ChevronDown,
  X
} from 'lucide-react';
import { cn } from './lib/utils';
import { Screen, UserProfile, Bus, Ticket as TicketType } from './types';
import { MOCK_PASS, MOCK_ARRIVALS, MOCK_RIDES, MOCK_BUSES, CHENNAI_STOPS } from './constants';

// --- Components ---

const BottomNav = ({ currentScreen, setScreen }: { currentScreen: Screen, setScreen: (s: Screen) => void }) => {
  const { t } = useTranslation();
  const navItems = [
    { id: 'DASHBOARD', label: t('home'), icon: Home },
    { id: 'MY_TICKETS', label: t('tickets'), icon: Ticket },
    { id: 'LIVE_TRACKING', label: t('live'), icon: MapIcon },
    { id: 'PROFILE', label: t('profile'), icon: User },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 mx-auto max-w-md bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 px-6 pb-8 pt-3 flex justify-between items-center z-50">
      {navItems.map((item) => (
        <button
          key={item.id}
          onClick={() => setScreen(item.id as Screen)}
          className={cn(
            "flex flex-col items-center gap-1 transition-colors",
            currentScreen === item.id ? "text-blue-600" : "text-slate-400 dark:text-slate-500"
          )}
        >
          <item.icon size={24} fill={currentScreen === item.id ? "currentColor" : "none"} />
          <span className="text-[10px] font-bold uppercase tracking-wider">{item.label}</span>
        </button>
      ))}
    </nav>
  );
};

// --- Screens ---

const SplashScreen = () => {
  const { t } = useTranslation();
  return (
    <div className="flex flex-col h-full bg-gradient-to-br from-blue-600 to-cyan-500 items-center justify-center text-white p-6">
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="flex flex-col items-center"
      >
        <div className="bg-white/20 p-6 rounded-[2rem] backdrop-blur-xl mb-6 shadow-2xl border border-white/30">
          <BusIcon size={80} className="text-white" />
        </div>
        <h1 className="text-4xl font-black tracking-tighter mb-2">{t('app_name')}</h1>
        <p className="text-blue-100 font-medium tracking-wide opacity-80">{t('login_subtitle')}</p>
      </motion.div>
      <div className="absolute bottom-12 flex flex-col items-center">
        <div className="flex gap-1.5 mb-4">
          <motion.div 
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ repeat: Infinity, duration: 1 }}
            className="size-2 rounded-full bg-white" 
          />
          <motion.div 
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ repeat: Infinity, duration: 1, delay: 0.2 }}
            className="size-2 rounded-full bg-white/60" 
          />
          <motion.div 
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ repeat: Infinity, duration: 1, delay: 0.4 }}
            className="size-2 rounded-full bg-white/30" 
          />
        </div>
        <p className="text-xs font-bold uppercase tracking-[0.2em] opacity-50">Chennai Smart Transport</p>
      </div>
    </div>
  );
};

const LoginScreen = ({ onLogin }: { onLogin: (phone: string) => void }) => {
  const { t } = useTranslation();
  const [phone, setPhone] = useState('');

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-950">
      <div className="h-2/5 bg-gradient-to-br from-blue-600 to-cyan-500 relative overflow-hidden flex flex-col justify-center items-center p-8">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 size-64 rounded-full bg-white/10" />
        <div className="absolute bottom-0 left-0 -ml-12 -mb-12 size-48 rounded-full bg-white/5" />
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="relative z-10 text-center"
        >
          <div className="bg-white/20 p-4 rounded-3xl backdrop-blur-md inline-block mb-4 border border-white/30">
            <BusIcon size={40} className="text-white" />
          </div>
          <h1 className="text-3xl font-black text-white tracking-tight">{t('login_title')}</h1>
          <p className="text-blue-100 opacity-80 mt-1">{t('login_subtitle')}</p>
        </motion.div>
      </div>
      
      <div className="flex-1 bg-white dark:bg-slate-950 -mt-8 rounded-t-[2.5rem] p-8 shadow-2xl z-20">
        <div className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-bold text-slate-500 uppercase tracking-wider ml-1">{t('mobile_number')}</label>
            <div className="relative group">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-2 border-r border-slate-200 dark:border-slate-800 pr-3">
                <span className="text-slate-400 font-bold">+91</span>
              </div>
              <input 
                type="tel"
                maxLength={10}
                value={phone}
                onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                className="w-full h-14 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl pl-20 pr-4 font-bold text-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all"
                placeholder={t('enter_mobile')}
              />
            </div>
          </div>
          
          <button 
            disabled={phone.length !== 10}
            onClick={() => onLogin(phone)}
            className="w-full h-14 bg-blue-600 disabled:bg-slate-300 text-white font-black text-lg rounded-2xl shadow-xl shadow-blue-600/30 active:scale-95 transition-all flex items-center justify-center gap-3"
          >
            {t('get_otp')}
            <ArrowRight size={20} />
          </button>
          
          <div className="flex items-center gap-4 py-2">
            <div className="flex-1 h-px bg-slate-100 dark:bg-slate-800" />
            <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Secure Access</span>
            <div className="flex-1 h-px bg-slate-100 dark:bg-slate-800" />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <button className="h-12 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl flex items-center justify-center gap-2 text-sm font-bold text-slate-600 dark:text-slate-400">
              <Smartphone size={18} />
              Google
            </button>
            <button className="h-12 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl flex items-center justify-center gap-2 text-sm font-bold text-slate-600 dark:text-slate-400">
              <ShieldCheck size={18} />
              Apple
            </button>
          </div>
        </div>
        
        <p className="mt-12 text-center text-slate-400 text-xs leading-relaxed">
          By continuing, you agree to our <span className="text-blue-600 font-bold">Terms of Service</span> and <span className="text-blue-600 font-bold">Privacy Policy</span>.
        </p>
      </div>
    </div>
  );
};

const OTPVerifyScreen = ({ onVerify, onBack }: { onVerify: (otp: string) => void, onBack: () => void }) => {
  const { t } = useTranslation();
  const [otp, setOtp] = useState('');

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-950 p-8">
      <button onClick={onBack} className="size-12 flex items-center justify-center rounded-2xl bg-slate-50 dark:bg-slate-900 mb-8">
        <ArrowLeft size={24} />
      </button>
      
      <div className="mb-10">
        <h1 className="text-3xl font-black mb-2">{t('verify_otp')}</h1>
        <p className="text-slate-500 font-medium">{t('otp_sent')}</p>
      </div>
      
      <div className="space-y-8">
        <div className="flex justify-between gap-3">
          <input 
            type="tel"
            maxLength={6}
            value={otp}
            onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
            className="w-full h-16 bg-slate-50 dark:bg-slate-900 border-2 border-slate-100 dark:border-slate-800 rounded-2xl text-center text-3xl font-black tracking-[0.5em] focus:border-blue-600 focus:ring-0 outline-none transition-all"
            placeholder="000000"
          />
        </div>
        
        <button 
          disabled={otp.length !== 6}
          onClick={() => onVerify(otp)}
          className="w-full h-16 bg-blue-600 disabled:bg-slate-300 text-white font-black text-lg rounded-2xl shadow-xl shadow-blue-600/30 active:scale-95 transition-all"
        >
          {t('login')}
        </button>
        
        <div className="text-center">
          <p className="text-slate-400 text-sm font-medium">
            Didn't receive code? <button 
              onClick={() => alert("Demo Mode: Your OTP is 123456")}
              className="text-blue-600 font-bold ml-1"
            >
              Resend OTP
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

const DashboardScreen = ({ setScreen, user }: { setScreen: (s: Screen) => void, user: UserProfile | null }) => {
  const { t } = useTranslation();
  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-950">
      <header className="flex items-center bg-white dark:bg-slate-900 px-6 py-4 justify-between border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <div className="size-12 rounded-2xl overflow-hidden border-2 border-blue-600/20 p-0.5">
            <img 
              src={getCDNImage('profile', 100, 100)} 
              alt="Profile" 
              className="h-full w-full object-cover rounded-[0.85rem]"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="flex flex-col">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Welcome back</span>
            <h1 className="text-slate-900 dark:text-slate-100 text-lg font-black leading-tight">{user?.displayName || 'Passenger'}</h1>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button className="size-11 flex items-center justify-center rounded-2xl bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 relative">
            <Bell size={22} />
            <span className="absolute top-2.5 right-2.5 size-2.5 bg-red-500 border-2 border-white dark:border-slate-800 rounded-full" />
          </button>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto p-6 space-y-8 pb-24">
        <section 
          onClick={() => setScreen('MY_PASS')}
          className="relative overflow-hidden rounded-[2rem] bg-gradient-to-br from-blue-600 to-cyan-500 p-8 text-white shadow-2xl shadow-blue-600/30 cursor-pointer group"
        >
          <div className="absolute top-0 right-0 -mr-12 -mt-12 size-48 rounded-full bg-white/10 group-hover:scale-110 transition-transform duration-500" />
          <div className="absolute bottom-0 left-0 -ml-8 -mb-8 size-32 rounded-full bg-white/5" />
          
          <div className="relative z-10">
            <div className="flex justify-between items-start mb-6">
              <div className="bg-white/20 text-[10px] font-black uppercase tracking-[0.2em] px-3 py-1.5 rounded-full backdrop-blur-md border border-white/20">
                {t('active')}
              </div>
              <BusIcon size={24} className="opacity-80" />
            </div>
            
            <h2 className="text-xl font-bold opacity-90 mb-1">{t('student_pass')}</h2>
            <div className="flex items-baseline gap-2 mb-6">
              <span className="text-5xl font-black">{MOCK_PASS.daysLeft}</span>
              <span className="text-lg font-bold opacity-70 uppercase tracking-widest">{t('date')}s Left</span>
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between text-[10px] font-black uppercase tracking-widest opacity-70">
                <span>Usage Progress</span>
                <span>{MOCK_PASS.usageCount} / {MOCK_PASS.totalDays} Days</span>
              </div>
              <div className="h-2.5 w-full rounded-full bg-white/20 overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${(MOCK_PASS.usageCount / MOCK_PASS.totalDays) * 100}%` }}
                  transition={{ duration: 1, ease: "easeOut" }}
                  className="h-full rounded-full bg-white shadow-[0_0_10px_rgba(255,255,255,0.5)]" 
                />
              </div>
            </div>
            
            <div className="mt-6 flex items-center justify-between">
              <p className="text-[10px] font-bold opacity-60 uppercase tracking-widest">Valid until {MOCK_PASS.expiryDate}</p>
              <ArrowRight size={18} className="opacity-60 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </section>

        <section>
          <div className="flex items-center justify-between mb-5 px-1">
            <h3 className="text-slate-900 dark:text-slate-100 text-xs font-black uppercase tracking-[0.2em]">{t('quick_actions')}</h3>
          </div>
          <div className="grid grid-cols-3 gap-4">
            {[
              { id: 'ROUTE_SEARCH', label: t('search_buses'), icon: Search, color: 'bg-blue-600' },
              { id: 'SPECIAL_PASSES', label: t('buy_new'), icon: Plus, color: 'bg-cyan-500' },
              { id: 'LIVE_TRACKING', label: t('live_tracking'), icon: MapIcon, color: 'bg-indigo-500' },
            ].map((action) => (
              <button 
                key={action.id}
                onClick={() => setScreen(action.id as Screen)}
                className="flex flex-col items-center gap-3 group"
              >
                <div className={cn("size-16 rounded-[1.5rem] flex items-center justify-center text-white shadow-lg group-active:scale-90 transition-all", action.color)}>
                  <action.icon size={28} />
                </div>
                <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest text-center leading-tight">{action.label}</span>
              </button>
            ))}
          </div>
        </section>

        <section className="rounded-[2rem] overflow-hidden border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xl shadow-slate-200/50">
          <div className="p-5 flex justify-between items-center border-b border-slate-50 dark:border-slate-800">
            <span className="text-xs font-black text-slate-900 dark:text-slate-100 uppercase tracking-widest">{t('nearby_stops')}</span>
            <button onClick={() => setScreen('ARRIVALS')} className="text-[10px] text-blue-600 font-black uppercase tracking-widest">View All</button>
          </div>
          <div className="relative h-44 w-full bg-slate-100 dark:bg-slate-800">
            <img 
              src={getCDNImage('map', 600, 300)} 
              alt="Route Map" 
              className="h-full w-full object-cover opacity-60 grayscale-[50%]"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="relative">
                <div className="size-6 rounded-full bg-blue-600/20 animate-ping absolute -inset-0" />
                <div className="size-6 rounded-full bg-blue-600 border-4 border-white shadow-lg relative z-10" />
              </div>
            </div>
            <div className="absolute bottom-4 left-4 right-4 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md p-3 rounded-xl border border-white/20 flex items-center gap-3">
              <div className="size-10 rounded-lg bg-blue-600 flex items-center justify-center text-white">
                <MapPin size={20} />
              </div>
              <div className="flex flex-col">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Closest Stop</span>
                <span className="text-sm font-bold">Adyar Depot (200m)</span>
              </div>
            </div>
          </div>
        </section>

        <section>
          <div className="flex items-center justify-between mb-5 px-1">
            <h3 className="text-slate-900 dark:text-slate-100 text-xs font-black uppercase tracking-[0.2em]">{t('history')}</h3>
            <button className="text-[10px] text-slate-400 font-black uppercase tracking-widest">See All</button>
          </div>
          <div className="space-y-4">
            {MOCK_RIDES.map(ride => (
              <div key={ride.id} className="flex items-center justify-between p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex items-center gap-4">
                  <div className="size-12 flex items-center justify-center rounded-xl bg-slate-50 dark:bg-slate-800 text-blue-600">
                    <BusIcon size={24} />
                  </div>
                  <div>
                    <p className="text-sm font-black tracking-tight">{ride.route} — {ride.destination}</p>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">{ride.time}</p>
                  </div>
                </div>
                <div className="flex flex-col items-end">
                  <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">{ride.status}</span>
                  <ChevronRight size={16} className="text-slate-300 mt-1" />
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
};

const MyPassScreen = ({ setScreen }: { setScreen: (s: Screen) => void }) => (
  <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-950">
    <header className="flex items-center bg-white dark:bg-slate-900 p-4 pb-2 justify-between border-b border-slate-200 dark:border-slate-800 sticky top-0 z-10">
      <button onClick={() => setScreen('DASHBOARD')} className="size-12 flex items-center justify-center">
        <ArrowLeft size={24} />
      </button>
      <h2 className="text-lg font-bold flex-1 text-center">Active Digital Pass</h2>
      <button className="size-12 flex items-center justify-center">
        <Info size={24} />
      </button>
    </header>

    <main className="flex-1 overflow-y-auto pb-24 px-6 pt-8">
      <h3 className="text-2xl font-extrabold text-center pb-2">Boarding Pass</h3>
      <p className="text-slate-500 text-sm text-center mb-6">Present this code to the reader upon boarding</p>
      
      <div className="bg-white dark:bg-slate-900 rounded-xl shadow-xl p-6 border border-slate-100 dark:border-slate-800 flex flex-col items-center">
        <div className="w-full aspect-square bg-white flex items-center justify-center p-4 border-2 border-blue-600/10 rounded-xl relative overflow-hidden">
          <img 
            src={getCDNImage('ticket', 400, 400)} 
            alt="QR Code" 
            className="w-full h-full object-contain"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-blue-600/5 to-transparent h-1 w-full top-1/2 opacity-30 animate-pulse" />
        </div>
        
        <div className="flex flex-col items-center gap-3 py-6 w-full">
          <div className="flex items-center gap-2 text-blue-600 font-semibold">
            <RefreshCw size={14} className="animate-spin-slow" />
            <p className="text-sm">Refreshes in 12s</p>
          </div>
          <button className="w-full bg-blue-600 text-white font-bold h-10 rounded-full shadow-md active:scale-95 transition-transform">
            Refresh Now
          </button>
        </div>

        <div className="w-full border-t border-dashed border-slate-200 dark:border-slate-700 my-2" />
        
        <div className="w-full pt-4 space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-slate-400 text-xs uppercase font-bold tracking-wider">Pass Type</p>
              <p className="text-slate-900 dark:text-slate-100 text-lg font-bold">Monthly Commuter</p>
            </div>
            <div className="text-right">
              <p className="text-slate-400 text-xs uppercase font-bold tracking-wider">Status</p>
              <span className="inline-flex items-center rounded-full bg-emerald-100 dark:bg-emerald-900/30 px-2.5 py-0.5 text-xs font-medium text-emerald-800 dark:text-emerald-400">
                Active
              </span>
            </div>
          </div>
          <div>
            <p className="text-slate-400 text-xs uppercase font-bold tracking-wider">Expires On</p>
            <p className="text-slate-900 dark:text-slate-100 text-base font-semibold">Oct 31, 2023 • 11:59 PM</p>
          </div>
        </div>
      </div>

      <div className="mt-8 flex flex-col items-center gap-2 text-slate-500">
        <Smartphone size={40} className="text-blue-600/60" />
        <p className="text-sm font-medium">Or tap your phone to the scanner</p>
      </div>

      <div className="mt-8 p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-start gap-3">
          <div className="bg-blue-600/10 p-2 rounded-lg">
            <CheckCircle2 size={20} className="text-blue-600" />
          </div>
          <div className="flex flex-col">
            <p className="text-sm font-bold">Offline Mode Available</p>
            <p className="text-xs text-slate-500">Validated and ready for use</p>
          </div>
        </div>
        <div className="w-12 h-6 bg-blue-600 rounded-full relative p-1">
          <div className="size-4 bg-white rounded-full absolute right-1" />
        </div>
      </div>
    </main>
  </div>
);

const LiveTrackingScreen = ({ setScreen }: { setScreen: (s: Screen) => void }) => {
  const [busPos, setBusPos] = useState({ x: 40, y: 30, rotation: 0 });
  const [eta, setEta] = useState(5);

  useEffect(() => {
    const path = [
      { x: 40, y: 30 },
      { x: 45, y: 32 },
      { x: 52, y: 38 },
      { x: 58, y: 45 },
      { x: 62, y: 55 },
      { x: 55, y: 65 },
      { x: 45, y: 70 },
      { x: 35, y: 65 },
      { x: 30, y: 55 },
      { x: 35, y: 40 },
    ];

    let currentIndex = 0;
    let step = 0;
    const totalSteps = 100; // More steps for smoother transition

    const interval = setInterval(() => {
      step++;
      if (step >= totalSteps) {
        step = 0;
        currentIndex = (currentIndex + 1) % path.length;
      }

      const nextIndex = (currentIndex + 1) % path.length;
      const start = path[currentIndex];
      const end = path[nextIndex];

      const x = start.x + (end.x - start.x) * (step / totalSteps);
      const y = start.y + (end.y - start.y) * (step / totalSteps);

      // Calculate rotation
      const dx = end.x - start.x;
      const dy = end.y - start.y;
      const rotation = Math.atan2(dy, dx) * (180 / Math.PI) + 90;

      setBusPos({ x, y, rotation });
      
      // Simulate changing ETA based on distance to a "target" (e.g. Adyar Depo at index 5)
      const distToTarget = Math.abs(currentIndex - 5) + (1 - step / totalSteps);
      setEta(Math.max(1, Math.round(distToTarget * 2)));
    }, 30); // Faster interval for smoother motion

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-950">
      <header className="flex items-center bg-white/90 backdrop-blur-md dark:bg-slate-900/90 p-4 border-b border-slate-200 dark:border-slate-800 justify-between z-20">
        <button onClick={() => setScreen('DASHBOARD')} className="size-10 flex items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800">
          <ArrowLeft size={24} />
        </button>
        <div className="flex flex-col items-center">
          <h2 className="text-lg font-bold">Chennai MTC Live</h2>
          <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest">Official Partner</span>
        </div>
        <button className="size-10 flex items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800">
          <Search size={24} />
        </button>
      </header>

      <div className="relative flex-1 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center transition-all duration-1000"
          style={{ 
            backgroundImage: `url("${getCDNImage('map', 800, 800)}")`,
            backgroundPosition: `${50 + (busPos.x - 50) * 0.5}% ${50 + (busPos.y - 50) * 0.5}%`
          }}
        >
          <motion.div 
            animate={{ 
              left: `${busPos.x}%`, 
              top: `${busPos.y}%`,
              rotate: busPos.rotation 
            }}
            transition={{ duration: 0.03, ease: "linear" }}
            className="absolute flex flex-col items-center z-10"
            style={{ transform: 'translate(-50%, -50%)' }}
          >
            <div className="bg-emerald-600 text-white text-[8px] font-bold px-1.5 py-0.5 rounded-full shadow-lg mb-1 whitespace-nowrap -rotate-[var(--motion-rotate)]" style={{ transform: `rotate(${-busPos.rotation}deg)` }}>23C</div>
            <div className="bg-white p-1.5 rounded-full shadow-xl border-2 border-emerald-600">
              <BusIcon size={18} className="text-emerald-600" />
            </div>
          </motion.div>
          
          {/* Static markers for stops */}
          <div className="absolute top-[65%] left-[55%] flex flex-col items-center opacity-60">
            <div className="size-3 bg-blue-600 rounded-full border-2 border-white shadow-sm" />
            <span className="text-[8px] font-bold bg-white/80 px-1 rounded mt-1">Adyar Depo</span>
          </div>
        </div>

        <div className="absolute top-4 right-4 flex flex-col gap-3 z-10">
          <div className="flex flex-col rounded-xl bg-white dark:bg-slate-900 shadow-xl border border-slate-200 dark:border-slate-800 overflow-hidden">
            <button className="p-3 hover:bg-slate-50 dark:hover:bg-slate-800 border-b border-slate-100 dark:border-slate-800"><Plus size={20} /></button>
            <button className="p-3 hover:bg-slate-50 dark:hover:bg-slate-800"><Plus size={20} className="rotate-45" /></button>
          </div>
          <button className="size-12 rounded-xl bg-white dark:bg-slate-900 shadow-xl border border-slate-200 dark:border-slate-800 flex items-center justify-center text-blue-600">
            <Navigation size={24} fill="currentColor" />
          </button>
        </div>

        <div className="absolute top-4 left-4 right-16 z-10">
          <div className="flex h-12 items-center bg-white dark:bg-slate-900 rounded-xl shadow-xl border border-slate-200 dark:border-slate-800 px-4 gap-3">
            <Search size={20} className="text-slate-400" />
            <input className="bg-transparent border-none focus:ring-0 text-sm w-full p-0" placeholder="Where are you going?" />
            <Mic size={20} className="text-slate-400" />
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 z-30 translate-y-2">
          <div className="bg-white dark:bg-slate-900 rounded-t-[2.5rem] shadow-[0_-8px_30px_rgb(0,0,0,0.12)] border-t border-slate-100 dark:border-slate-800 p-6 pb-12">
            <div className="mx-auto w-12 h-1.5 rounded-full bg-slate-200 dark:bg-slate-700 mb-6" />
            <div className="flex items-start justify-between mb-6">
              <div className="flex flex-col gap-1">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Current Stop</span>
                <h3 className="text-xl font-extrabold">Adyar Depo</h3>
              </div>
              <div className="bg-blue-600/10 text-blue-600 px-3 py-1.5 rounded-lg flex items-center gap-2">
                <History size={14} />
                <span className="text-xs font-bold">Recent</span>
              </div>
            </div>
            <div className="bg-slate-50 dark:bg-slate-800/50 rounded-2xl p-5 border border-slate-100 dark:border-slate-800">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-4">
                  <div className="size-12 rounded-xl bg-emerald-600 flex items-center justify-center text-white font-black text-lg">23C</div>
                  <div className="flex flex-col">
                    <span className="text-sm font-bold">Besant Nagar</span>
                    <span className="text-xs text-slate-500">via Mylapore</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-2xl font-black text-emerald-600">{eta}m</span>
                  <p className="text-[10px] font-bold text-slate-400 uppercase">Arriving</p>
                </div>
              </div>
              <div className="flex items-center gap-6 pt-4 border-t border-slate-200 dark:border-slate-700">
                <div className="flex items-center gap-2">
                  <Users size={20} className="text-slate-400" />
                  <div className="flex flex-col">
                    <span className="text-[10px] font-bold text-slate-400 uppercase">Occupancy</span>
                    <span className="text-xs font-bold text-orange-500">Moderate (60%)</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <RefreshCw size={20} className="text-slate-400" />
                  <div className="flex flex-col">
                    <span className="text-[10px] font-bold text-slate-400 uppercase">Tracking</span>
                    <span className="text-xs font-bold text-emerald-500">Live GPS</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 mt-6">
              <button className="flex items-center justify-center gap-2 bg-blue-600 text-white font-bold py-4 rounded-xl shadow-lg shadow-blue-600/30">
                <Navigation size={20} />
                <span>Directions</span>
              </button>
              <button className="flex items-center justify-center gap-2 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold py-4 rounded-xl border border-slate-200 dark:border-slate-700">
                <Bell size={20} />
                <span>Set Alert</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const ProfileScreen = ({ setScreen, onLogout, user }: { setScreen: (s: Screen) => void, onLogout: () => void, user: UserProfile | null }) => (
  <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-950">
    <header className="sticky top-0 z-50 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
      <div className="flex items-center justify-between px-4 py-4">
        <button onClick={() => setScreen('DASHBOARD')} className="size-10 flex items-center justify-center rounded-full hover:bg-blue-600/10 transition-colors">
          <ArrowLeft size={20} />
        </button>
        <h1 className="text-lg font-bold tracking-tight">Passenger Profile</h1>
        <button className="size-10 flex items-center justify-center rounded-full hover:bg-blue-600/10 transition-colors">
          <Settings size={20} />
        </button>
      </div>
    </header>

    <main className="flex-1 overflow-y-auto px-4 py-6 space-y-8 pb-24">
      <section className="flex flex-col items-center">
        <div className="relative mb-4">
          <div className="size-32 rounded-full border-4 border-white dark:border-slate-800 shadow-xl overflow-hidden bg-blue-600/10 flex items-center justify-center">
            <img 
              src={getCDNImage('profile', 300, 300)} 
              alt="Profile" 
              className="size-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <button className="absolute bottom-0 right-0 bg-blue-600 text-white p-2 rounded-full shadow-lg border-2 border-white dark:border-slate-900">
            <Plus size={16} />
          </button>
        </div>
        <div className="text-center">
          <h2 className="text-2xl font-bold">Karthik Raja</h2>
          <div className="flex flex-col items-center gap-1 mt-1 text-slate-500">
            <div className="flex items-center gap-2">
              <Smartphone size={16} />
              <span className="text-sm font-medium">+91 98765 43210</span>
            </div>
            <div className="flex items-center gap-2">
              <Cloud size={16} />
              <span className="text-sm font-medium">karthik.raja@email.com</span>
            </div>
          </div>
        </div>
      </section>

      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white dark:bg-slate-900 p-3 rounded-xl shadow-sm border border-slate-100 dark:border-slate-800 text-center">
          <p className="text-xs text-slate-500 mb-1">Passes</p>
          <p className="text-lg font-bold text-blue-600">02</p>
        </div>
        <div className="bg-white dark:bg-slate-900 p-3 rounded-xl shadow-sm border border-slate-100 dark:border-slate-800 text-center">
          <p className="text-xs text-slate-500 mb-1">Trips</p>
          <p className="text-lg font-bold text-blue-600">124</p>
        </div>
        <div className="bg-white dark:bg-slate-900 p-3 rounded-xl shadow-sm border border-slate-100 dark:border-slate-800 text-center">
          <p className="text-xs text-slate-500 mb-1">Points</p>
          <p className="text-lg font-bold text-blue-600">850</p>
        </div>
      </div>

      <section className="space-y-4">
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 px-1">Account & Billing</h3>
        <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 overflow-hidden">
          <button className="w-full flex items-center justify-between p-4 active:bg-slate-50 transition-colors">
            <div className="flex items-center gap-4">
              <div className="size-10 rounded-lg bg-blue-600/10 flex items-center justify-center text-blue-600">
                <CreditCard size={20} />
              </div>
              <span className="font-medium">Payment Methods</span>
            </div>
            <ChevronRight size={20} className="text-slate-400" />
          </button>
          <div className="mx-4 border-t border-slate-100 dark:border-slate-800" />
          <button className="w-full flex items-center justify-between p-4 active:bg-slate-50 transition-colors">
            <div className="flex items-center gap-4">
              <div className="size-10 rounded-lg bg-blue-600/10 flex items-center justify-center text-blue-600">
                <RefreshCw size={20} />
              </div>
              <span className="font-medium">Cloud Sync Settings</span>
            </div>
            <ChevronRight size={20} className="text-slate-400" />
          </button>
        </div>
      </section>

      <button 
        onClick={onLogout}
        className="w-full py-4 rounded-xl text-red-500 font-bold bg-red-50 dark:bg-red-900/10 border border-red-100 dark:border-red-900/20 active:scale-95 transition-transform"
      >
        Logout
      </button>
    </main>
  </div>
);

const PaymentScreen = ({ setScreen, bus }: { setScreen: (s: Screen) => void, bus: Bus | null }) => (
  <div className="flex flex-col h-full bg-white dark:bg-slate-900">
    <header className="flex items-center bg-white dark:bg-slate-900 p-4 border-b border-slate-100 dark:border-slate-800 sticky top-0 z-10">
      <button onClick={() => setScreen('DASHBOARD')} className="size-10 flex items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800">
        <ArrowLeft size={24} />
      </button>
      <h2 className="text-lg font-bold flex-1 text-center pr-10">UPI Payment</h2>
    </header>
    <div className="flex-1 overflow-y-auto pb-32">
      <div className="m-4 p-5 bg-blue-600/5 dark:bg-blue-600/10 rounded-xl border border-blue-600/10">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-blue-600/10 rounded-lg text-blue-600">
            <BusIcon size={24} />
          </div>
          <div>
            <h3 className="text-base font-bold">{bus?.routeName || 'Chennai Monthly Pass'}</h3>
            <p className="text-slate-500 text-xs">{bus?.type || 'MTC Regular Service'}</p>
          </div>
        </div>
        <div className="space-y-3 border-t border-slate-200 dark:border-slate-700 pt-4">
          <div className="flex justify-between items-center">
            <p className="text-slate-600 text-sm">Base Fare</p>
            <p className="text-sm font-semibold">₹1,000.00</p>
          </div>
          <div className="flex justify-between items-center">
            <p className="text-slate-600 text-sm">GST (18%)</p>
            <p className="text-sm font-semibold">₹180.00</p>
          </div>
          <div className="flex justify-between items-center pt-2 border-t border-dashed border-slate-300">
            <p className="text-base font-bold">Total Amount</p>
            <p className="text-blue-600 text-xl font-extrabold">₹1,180.00</p>
          </div>
        </div>
      </div>
      <div className="px-4">
        <h3 className="text-base font-bold mb-4 flex items-center gap-2">
          <CreditCard size={18} className="text-blue-600" />
          Pay via UPI App
        </h3>
        <div className="space-y-3">
          {['Google Pay', 'PhonePe', 'Paytm'].map((app, i) => (
            <div key={app} className="flex items-center justify-between p-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl hover:border-blue-600 transition-all cursor-pointer">
              <div className="flex items-center gap-4">
                <div className="size-10 flex items-center justify-center bg-slate-50 dark:bg-slate-700 rounded-lg">
                  <img 
                    src={i === 0 ? "https://lh3.googleusercontent.com/aida-public/AB6AXuDAaOwGS10buTUnAdbOY2im97jd8Xmu3sennn1aVvvDeKsOe5AP5YRsmGD4gZuQjtLN0Zl0kiF0Pe0iWH93n34vD7bUmBhqmybHOljBARNbLxtzRMa8MSj_R0KO9VLEpMXnTEP8IGifZIK8igah6-m-wNWtq_kIM97NXwahRoh6OZiS1rCvjJCulAbyZaUiYm8D0vj0H0ODm8ZVCVylI6xNveqh_qUSBQ3wBuMnyBSsIb4uSzvkvK4RxpC8-SA73KZVyxFYSFgYJQQ" : i === 1 ? "https://lh3.googleusercontent.com/aida-public/AB6AXuDy4xtgNSD5or64oPmcnEW_rlu_NRSKya7aQ3ZwfcGTyepFJo8Es1caqvUYJUmX4UGfarmNNVx6y39syTlAznP1RYUGHg14Wa2xC0HwYu8lh0XL5cm4gh7mWz8EwijR47Aylkxl6z2dQwHcBRcWLyfBLNm7YHYzfnO32RnrpkJed6eHI7uVFmKXCyfqnAqhOupBVbJ4llBpOmK-qT-C5mZhNNGST8Xi7gkY-1-Ex_rAyWtEpgltD0kOusZT3hjE1K6kWJZmp_eqQYE" : "https://lh3.googleusercontent.com/aida-public/AB6AXuAWsMJrd5RJuaXdz3G3nXTrsiuErXwRbV24AekKu9Cb79SDPE3xYBSDn7_eayQkb49MICDrbtvrjLOtU6NbBGzh0rdjC8lMZvdIb7jbiijo1OSbeznlKZFiiIDQSVTFdXalfUOYBHr-APyoeHyLSWmP_ti-h3lHeHbvJezMIboXsDKEGf2chhA1PSc-YKUyAytaHqs5qV7VmMoxV-qDgaU0X6feMwwEV2HBPyp2QaRRxaTiFMgt6FPssbqF3DmZEEBjv7Sb90vJsSU"} 
                    alt={app} 
                    className="w-8 h-8 object-contain"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <span className="font-semibold">{app}</span>
              </div>
              <input type="radio" name="upi" defaultChecked={i === 0} className="w-5 h-5 text-blue-600" />
            </div>
          ))}
        </div>
      </div>
    </div>
    <div className="fixed bottom-0 left-0 right-0 p-4 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 max-w-md mx-auto z-20">
      <button className="w-full bg-blue-600 text-white py-4 rounded-xl font-bold text-lg shadow-lg shadow-blue-600/20 flex items-center justify-center gap-2">
        Pay ₹1,180.00
        <ArrowRight size={20} />
      </button>
    </div>
  </div>
);

const LanguageScreen = ({ setScreen }: { setScreen: (s: Screen) => void }) => (
  <div className="flex flex-col h-full bg-white dark:bg-slate-950">
    <header className="flex items-center p-4 pb-2 justify-between sticky top-0 z-10">
      <button onClick={() => setScreen('PROFILE')} className="size-10 flex items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800">
        <ArrowLeft size={24} />
      </button>
      <h2 className="text-lg font-bold flex-1 text-center pr-10">Language Selection</h2>
    </header>
    <div className="px-6 pt-8 pb-4">
      <h3 className="text-3xl font-extrabold text-center pb-3">Choose your language</h3>
      <p className="text-slate-600 text-base text-center">Select your preferred language for managing your bus passes in Chennai.</p>
    </div>
    <div className="flex flex-col gap-4 p-6 flex-grow">
      <div className="group relative flex flex-col items-center justify-center gap-4 rounded-xl border-2 border-blue-600 bg-blue-600/5 p-8 cursor-pointer">
        <CheckCircle2 className="absolute top-4 right-4 text-blue-600" />
        <div className="size-16 flex items-center justify-center rounded-full bg-blue-600 text-white">
          <Languages size={32} />
        </div>
        <div className="text-center">
          <p className="text-xl font-bold">English</p>
          <p className="text-sm font-medium text-slate-500">Default App Language</p>
        </div>
      </div>
      <div className="group relative flex flex-col items-center justify-center gap-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 cursor-pointer">
        <div className="size-16 flex items-center justify-center rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600">
          <Languages size={32} />
        </div>
        <div className="text-center">
          <p className="text-xl font-bold">தமிழ் (Tamil)</p>
          <p className="text-sm font-medium text-slate-500">சென்னை பேருந்து சேவை</p>
        </div>
      </div>
    </div>
    <div className="p-6 border-t border-slate-100 dark:border-slate-900">
      <button className="w-full bg-blue-600 text-white font-bold py-4 rounded-xl shadow-lg shadow-blue-600/20">
        Set as Default
      </button>
    </div>
  </div>
);

const ArrivalsScreen = ({ setScreen }: { setScreen: (s: Screen) => void }) => (
  <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-950">
    <header className="px-4 py-2 bg-white dark:bg-slate-900 sticky top-0 z-10 border-b border-slate-100 dark:border-slate-800">
      <div className="flex items-center justify-between">
        <button onClick={() => setScreen('DASHBOARD')} className="p-2 hover:bg-blue-600/10 rounded-full">
          <ArrowLeft size={20} />
        </button>
        <div className="flex flex-col items-center">
          <h1 className="text-lg font-extrabold">Chennai Central</h1>
          <div className="flex items-center gap-1.5">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-500 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-500">Live Tracking</span>
          </div>
        </div>
        <div className="flex gap-1">
          <button className="p-2 text-emerald-500"><Star size={20} fill="currentColor" /></button>
          <button className="p-2"><MoreHorizontal size={20} /></button>
        </div>
      </div>
    </header>
    <main className="flex-1 px-4 py-4 space-y-4 overflow-y-auto pb-24">
      <div className="w-full h-32 rounded-xl overflow-hidden relative border border-slate-200 dark:border-slate-800">
        <img 
          src={getCDNImage('map', 600, 300)} 
          alt="Map" 
          className="w-full h-full object-cover grayscale opacity-80"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="bg-emerald-500 p-2 rounded-full shadow-lg border-2 border-white">
            <BusIcon size={20} className="text-white" />
          </div>
        </div>
      </div>
      <div className="flex gap-2 overflow-x-auto no-scrollbar py-2">
        <button className="bg-emerald-500 text-white px-5 py-2 rounded-full text-sm font-bold shrink-0">All Buses</button>
        {['1A', '27L', '17D', '54'].map(route => (
          <button key={route} className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-5 py-2 rounded-full text-sm font-medium shrink-0">{route}</button>
        ))}
      </div>
      <h2 className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Upcoming Arrivals</h2>
      {MOCK_ARRIVALS.map((arrival, i) => (
        <div key={i} className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-100 dark:border-slate-800 flex items-center justify-between shadow-sm">
          <div className="flex gap-4 items-center">
            <div className="flex flex-col items-center justify-center bg-emerald-500/10 rounded-lg w-14 h-14 border border-emerald-500/20">
              <span className="text-emerald-600 font-extrabold text-lg">{arrival.route}</span>
              <AlertCircle size={14} className="text-emerald-600" />
            </div>
            <div>
              <p className="text-base font-bold">{arrival.destination}</p>
              <div className="flex items-center gap-3 mt-0.5">
                <div className="flex items-center gap-1 text-[11px] font-medium text-emerald-600 bg-emerald-50 dark:bg-emerald-900/20 px-1.5 py-0.5 rounded">
                  <Users size={12} />
                  <span>{arrival.crowd} Crowd</span>
                </div>
                <p className="text-xs text-slate-500">Via: {arrival.via}</p>
              </div>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xl font-black text-emerald-500">{arrival.time}</p>
            <p className="text-[10px] font-bold text-slate-400 uppercase">{arrival.status}</p>
          </div>
        </div>
      ))}
    </main>
  </div>
);

const SpecialPassesScreen = ({ setScreen }: { setScreen: (s: Screen) => void }) => (
  <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-950">
    <header className="flex items-center bg-white dark:bg-slate-900 px-4 pb-2 pt-12 justify-between border-b border-slate-100 dark:border-slate-800 sticky top-0 z-10">
      <button onClick={() => setScreen('DASHBOARD')} className="size-10 flex items-center justify-center">
        <ArrowLeft size={24} />
      </button>
      <h1 className="text-lg font-bold flex-1 text-center">Special MTC Passes</h1>
      <button className="text-emerald-500 size-10 flex items-center justify-center">
        <Info size={24} />
      </button>
    </header>
    <main className="flex-1 overflow-y-auto px-4 py-6 space-y-6 pb-24">
      <h2 className="text-xl font-bold">Eligibility-Based Passes</h2>
      <div className="space-y-4">
        {[
          { title: 'Student Pass', icon: School, tag: 'Academic Year', desc: 'Requires valid Student ID and verification', img: getCDNImage('student', 200, 200) },
          { title: 'Senior Citizen', icon: User, tag: 'Concessional', desc: 'Age 60+ (Requires Aadhar card verification)', img: getCDNImage('senior', 200, 200) },
          { title: 'Differently Abled', icon: Accessibility, tag: 'Free Travel', desc: 'Verification of medical certificate required', img: getCDNImage('accessibility', 200, 200) }
        ].map((pass, i) => (
          <div key={i} className="flex items-stretch justify-between gap-4 rounded-xl bg-white dark:bg-slate-900 p-4 shadow-sm border border-slate-100 dark:border-slate-800">
            <div className="flex flex-[2_2_0px] flex-col justify-between gap-3">
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2 text-emerald-500">
                  <pass.icon size={14} />
                  <p className="text-xs font-semibold uppercase tracking-wider">{pass.tag}</p>
                </div>
                <p className="text-lg font-bold">{pass.title}</p>
                <p className="text-slate-500 text-xs leading-normal">{pass.desc}</p>
              </div>
              <button className="w-full h-9 rounded-lg bg-emerald-500 text-slate-900 text-sm font-bold flex items-center justify-center gap-1">
                Apply Now
              </button>
            </div>
            <div className="w-24 h-24 bg-emerald-500/10 rounded-xl overflow-hidden">
              <img src={pass.img} alt={pass.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            </div>
          </div>
        ))}
      </div>
    </main>
  </div>
);

const MyTicketsScreen = ({ setScreen, tickets }: { setScreen: (s: Screen) => void, tickets: TicketType[] }) => {
  const { t } = useTranslation();
  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-950">
      <header className="sticky top-0 z-30 flex items-center bg-white/90 dark:bg-slate-900/90 backdrop-blur-md px-6 py-4 justify-between border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-4">
          <button onClick={() => setScreen('DASHBOARD')} className="size-10 flex items-center justify-center rounded-xl bg-slate-50 dark:bg-slate-800">
            <ArrowLeft size={20} />
          </button>
          <h2 className="text-xl font-black tracking-tight">{t('my_tickets')}</h2>
        </div>
        <button className="size-10 flex items-center justify-center rounded-xl bg-slate-50 dark:bg-slate-800">
          <History size={20} />
        </button>
      </header>
      
      <main className="flex-1 overflow-y-auto p-6 space-y-8 pb-24">
        {tickets.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center space-y-6 opacity-50">
            <div className="size-32 rounded-full bg-slate-200 dark:bg-slate-800 flex items-center justify-center">
              <Ticket size={64} className="text-slate-400" />
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-bold">No Tickets Found</h3>
              <p className="text-sm font-medium max-w-[200px]">Your booked tickets will appear here.</p>
            </div>
            <button 
              onClick={() => setScreen('ROUTE_SEARCH')}
              className="px-8 py-3 bg-blue-600 text-white font-black rounded-xl shadow-lg"
            >
              Book Now
            </button>
          </div>
        ) : (
          tickets.map((ticket) => (
            <motion.div 
              key={ticket.id}
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="relative bg-white dark:bg-slate-900 rounded-[2.5rem] overflow-hidden shadow-2xl border border-slate-100 dark:border-slate-800"
            >
              <div className="h-4 bg-gradient-to-r from-blue-600 to-cyan-500 w-full" />
              <div className="p-8">
                <div className="flex justify-between items-start mb-8">
                  <div>
                    <p className="text-blue-600 text-[10px] font-black uppercase tracking-[0.2em] mb-1">Chennai Ride</p>
                    <h4 className="text-3xl font-black tracking-tighter">{ticket.busNumber}</h4>
                    <p className="text-slate-500 font-bold text-sm uppercase tracking-widest">{ticket.routeName}</p>
                  </div>
                  <div className="bg-emerald-500/10 px-4 py-1.5 rounded-full border border-emerald-500/20">
                    <span className="text-emerald-600 text-[10px] font-black uppercase tracking-widest">{t('active')}</span>
                  </div>
                </div>
                
                <div className="flex flex-col items-center justify-center py-8 border-y border-dashed border-slate-200 dark:border-slate-700 my-6 relative">
                  <div className="absolute -left-12 top-1/2 -translate-y-1/2 size-8 rounded-full bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800" />
                  <div className="absolute -right-12 top-1/2 -translate-y-1/2 size-8 rounded-full bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800" />
                  
                  <div className="bg-white p-4 rounded-3xl shadow-2xl border-2 border-slate-50">
                    <QRCodeSVG value={ticket.qrCode} size={160} level="H" includeMargin={true} />
                  </div>
                  <p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.3em] mt-6">{ticket.id}</p>
                </div>
                
                <div className="grid grid-cols-2 gap-y-6 gap-x-4">
                  <div>
                    <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-1">{t('passenger_name')}</p>
                    <p className="font-bold text-sm truncate">{ticket.passengerName}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-1">{t('bus_number')}</p>
                    <p className="font-bold text-sm">{ticket.busNumber}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-1">{t('issue_time')}</p>
                    <p className="font-bold text-sm">{ticket.travelDate}, {ticket.travelTime}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-1">{t('fare')}</p>
                    <p className="font-bold text-sm text-blue-600">₹{ticket.fare}.00</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-blue-600 px-8 py-5 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="size-8 rounded-full bg-white/20 flex items-center justify-center text-white">
                    <ShieldCheck size={18} />
                  </div>
                  <span className="text-white font-black text-sm uppercase tracking-widest">Verified Ticket</span>
                </div>
                <div className="text-white/60 text-[10px] font-black uppercase tracking-widest">Cloud Secured</div>
              </div>
            </motion.div>
          ))
        )}
      </main>
    </div>
  );
};

const RouteSearchScreen = ({ setScreen }: { setScreen: (s: Screen) => void }) => {
  const { t } = useTranslation();
  const [from, setFrom] = useState('T. Nagar');
  const [to, setTo] = useState('');
  const [showFromSuggestions, setShowFromSuggestions] = useState(false);
  const [showToSuggestions, setShowToSuggestions] = useState(false);

  const filteredStops = (query: string) => 
    CHENNAI_STOPS.filter(stop => stop.toLowerCase().includes(query.toLowerCase()));

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-950">
      <header className="flex items-center justify-between px-6 pt-8 pb-4 bg-white dark:bg-slate-900 shadow-sm">
        <div className="flex items-center gap-3">
          <button onClick={() => setScreen('DASHBOARD')} className="size-10 flex items-center justify-center rounded-xl bg-slate-50 dark:bg-slate-800">
            <ArrowLeft size={20} />
          </button>
          <div>
            <h1 className="text-xl font-black tracking-tight">{t('search_buses')}</h1>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Chennai Smart Network</p>
          </div>
        </div>
      </header>
      
      <main className="flex-1 overflow-y-auto px-6 py-6 space-y-8 pb-24">
        <section className="bg-white dark:bg-slate-900 rounded-[2rem] p-8 shadow-2xl shadow-slate-200/50 border border-slate-100 dark:border-slate-800 space-y-6">
          <div className="relative">
            <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-2 block ml-1">{t('from')}</label>
            <div className="relative">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 text-blue-600">
                <MapPin size={20} />
              </div>
              <input 
                value={from}
                onChange={(e) => { setFrom(e.target.value); setShowFromSuggestions(true); }}
                onFocus={() => setShowFromSuggestions(true)}
                className="w-full h-14 bg-slate-50 dark:bg-slate-800 rounded-2xl pl-12 pr-4 font-bold text-sm focus:ring-2 focus:ring-blue-600 outline-none transition-all"
                placeholder="Starting Point"
              />
              {showFromSuggestions && from && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-100 dark:border-slate-800 z-50 max-h-48 overflow-y-auto">
                  {filteredStops(from).map(stop => (
                    <button 
                      key={stop}
                      onClick={() => { setFrom(stop); setShowFromSuggestions(false); }}
                      className="w-full px-5 py-3 text-left text-sm font-bold hover:bg-slate-50 dark:hover:bg-slate-800 border-b border-slate-50 dark:border-slate-800 last:border-0"
                    >
                      {stop}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="flex justify-center -my-3 relative z-10">
            <button 
              onClick={() => { const temp = from; setFrom(to); setTo(temp); }}
              className="bg-blue-600 text-white size-10 rounded-full shadow-lg flex items-center justify-center active:rotate-180 transition-transform duration-500"
            >
              <RefreshCw size={18} />
            </button>
          </div>

          <div className="relative">
            <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-2 block ml-1">{t('to')}</label>
            <div className="relative">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 text-blue-600">
                <Navigation size={20} />
              </div>
              <input 
                value={to}
                onChange={(e) => { setTo(e.target.value); setShowToSuggestions(true); }}
                onFocus={() => setShowToSuggestions(true)}
                className="w-full h-14 bg-slate-50 dark:bg-slate-800 rounded-2xl pl-12 pr-4 font-bold text-sm focus:ring-2 focus:ring-blue-600 outline-none transition-all"
                placeholder="Destination"
              />
              {showToSuggestions && to && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-100 dark:border-slate-800 z-50 max-h-48 overflow-y-auto">
                  {filteredStops(to).map(stop => (
                    <button 
                      key={stop}
                      onClick={() => { setTo(stop); setShowToSuggestions(false); }}
                      className="w-full px-5 py-3 text-left text-sm font-bold hover:bg-slate-50 dark:hover:bg-slate-800 border-b border-slate-50 dark:border-slate-800 last:border-0"
                    >
                      {stop}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 ml-1">{t('date')}</label>
              <div className="h-14 bg-slate-50 dark:bg-slate-800 rounded-2xl flex items-center px-4 gap-3">
                <Calendar size={18} className="text-slate-400" />
                <span className="text-sm font-bold">Today</span>
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 ml-1">Time</label>
              <div className="h-14 bg-slate-50 dark:bg-slate-800 rounded-2xl flex items-center px-4 gap-3">
                <Clock size={18} className="text-slate-400" />
                <span className="text-sm font-bold">Now</span>
              </div>
            </div>
          </div>

          <button 
            disabled={!from || !to}
            onClick={() => setScreen('AVAILABLE_BUSES')}
            className="w-full h-16 bg-blue-600 disabled:bg-slate-200 text-white font-black text-lg rounded-2xl shadow-xl shadow-blue-600/30 flex items-center justify-center gap-3 active:scale-95 transition-all mt-4"
          >
            <Search size={22} />
            {t('search_buses')}
          </button>
        </section>

        <section className="space-y-4">
          <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 px-1">Recent Searches</h3>
          <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2">
            {['T. Nagar → Adyar', 'Broadway → Guindy', 'Tambaram → CMBT'].map((search, i) => (
              <button key={i} className="px-4 py-3 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl text-xs font-bold whitespace-nowrap shadow-sm">
                {search}
              </button>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
};

const AvailableBusesScreen = ({ setScreen, onSelectBus }: { setScreen: (s: Screen) => void, onSelectBus: (bus: Bus) => void }) => {
  const { t } = useTranslation();
  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-950">
      <header className="sticky top-0 z-30 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-100 dark:border-slate-800 px-6 py-4">
        <div className="flex items-center gap-4">
          <button onClick={() => setScreen('ROUTE_SEARCH')} className="size-10 flex items-center justify-center rounded-xl bg-slate-50 dark:bg-slate-800">
            <ArrowLeft size={20} />
          </button>
          <div>
            <h1 className="text-xl font-black tracking-tight">{t('available_buses')}</h1>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">3 Buses Found</p>
          </div>
        </div>
      </header>
      
      <main className="flex-1 p-6 space-y-6 overflow-y-auto pb-24">
        {MOCK_BUSES.map((bus) => (
          <motion.div 
            key={bus.id}
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="rounded-[2rem] overflow-hidden shadow-xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900/50 flex flex-col group"
          >
            <div className="h-32 w-full relative overflow-hidden">
              <img 
                src={getCDNImage('mtc-bus', 600, 400)} 
                alt="Bus" 
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              <div className="absolute top-4 right-4 bg-emerald-500 text-white px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg">
                {bus.type.replace('_', ' ')}
              </div>
              <div className="absolute bottom-4 left-4 right-4 flex justify-between items-end">
                <div className="flex flex-col">
                  <span className="text-white font-black text-2xl tracking-tighter">{bus.busNumber}</span>
                  <span className="text-white/80 text-[10px] font-bold uppercase tracking-widest">{bus.routeName}</span>
                </div>
                <div className="flex items-center gap-1.5 text-white/90">
                  <Clock size={14} />
                  <span className="text-sm font-bold">{bus.departureTime}</span>
                </div>
              </div>
            </div>
            
            <div className="p-6 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="size-10 rounded-xl bg-blue-600/10 flex items-center justify-center text-blue-600">
                    <MapPin size={20} />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{t('route')}</span>
                    <span className="text-sm font-bold">{bus.from} → {bus.to}</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{t('fare')}</span>
                  <p className="text-xl font-black text-blue-600">₹{bus.fare}</p>
                </div>
              </div>
              
              <div className="flex items-center justify-between pt-4 border-t border-slate-50 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <div className={cn(
                    "size-2 rounded-full animate-pulse",
                    bus.seatsAvailable > 10 ? "bg-emerald-500" : "bg-orange-500"
                  )} />
                  <span className="text-xs font-bold text-slate-500">{bus.seatsAvailable} {t('seat_availability')} Available</span>
                </div>
                <button 
                  onClick={() => onSelectBus(bus)}
                  className="bg-blue-600 hover:bg-blue-700 text-white h-12 px-8 rounded-xl font-black text-sm shadow-lg shadow-blue-600/20 active:scale-95 transition-all"
                >
                  {t('book')}
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </main>
    </div>
  );
};

const BookingSummaryScreen = ({ setScreen, bus, onConfirm }: { setScreen: (s: Screen) => void, bus: Bus | null, onConfirm: () => void }) => {
  const { t } = useTranslation();
  if (!bus) return null;

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-950">
      <header className="flex items-center bg-white dark:bg-slate-900 px-6 py-4 justify-between sticky top-0 z-30 border-b border-slate-100 dark:border-slate-800">
        <button onClick={() => setScreen('AVAILABLE_BUSES')} className="size-10 flex items-center justify-center rounded-xl bg-slate-50 dark:bg-slate-800">
          <ArrowLeft size={20} />
        </button>
        <h2 className="text-lg font-black tracking-tight">{t('booking_summary')}</h2>
        <div className="size-10" />
      </header>
      
      <main className="flex-1 overflow-y-auto p-6 space-y-6 pb-32">
        <div className="bg-white dark:bg-slate-900 rounded-[2rem] shadow-2xl border border-slate-100 dark:border-slate-800 overflow-hidden">
          <div className="h-40 relative">
            <img 
              src={getCDNImage('bus-interior', 800, 450)} 
              alt="Bus Interior" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900 to-transparent" />
            <div className="absolute bottom-6 left-6">
              <span className="bg-blue-600 text-white px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest mb-2 inline-block">MTC Express</span>
              <h3 className="text-white text-2xl font-black tracking-tighter">{bus.busNumber} — {bus.routeName}</h3>
            </div>
          </div>
          
          <div className="p-8 space-y-6">
            <div className="grid grid-cols-2 gap-8">
              <div className="space-y-1">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{t('from')}</p>
                <p className="text-base font-bold">{bus.from}</p>
              </div>
              <div className="space-y-1 text-right">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{t('to')}</p>
                <p className="text-base font-bold">{bus.to}</p>
              </div>
              <div className="space-y-1">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{t('date')}</p>
                <p className="text-base font-bold">{new Date().toLocaleDateString()}</p>
              </div>
              <div className="space-y-1 text-right">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Time</p>
                <p className="text-base font-bold">{bus.departureTime}</p>
              </div>
            </div>
            
            <div className="pt-6 border-t border-slate-100 dark:border-slate-800 space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm font-bold text-slate-500">Base Fare</span>
                <span className="text-sm font-bold">₹{bus.fare - 2}.00</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-bold text-slate-500">Service Fee</span>
                <span className="text-sm font-bold">₹2.00</span>
              </div>
              <div className="flex justify-between items-center pt-4 border-t border-dashed border-slate-200 dark:border-slate-700">
                <span className="text-lg font-black">Total Payable</span>
                <span className="text-2xl font-black text-blue-600">₹{bus.fare}.00</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-blue-600/5 dark:bg-blue-600/10 rounded-2xl p-5 border border-blue-600/10 flex items-start gap-4">
          <div className="size-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shrink-0">
            <ShieldCheck size={24} />
          </div>
          <div className="flex flex-col">
            <h4 className="text-sm font-bold text-blue-600">Secure Cloud Booking</h4>
            <p className="text-xs text-slate-500 leading-relaxed mt-1">Your ticket will be stored securely in our cloud database and accessible offline.</p>
          </div>
        </div>
      </main>
      
      <div className="fixed bottom-0 left-0 right-0 p-6 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 max-w-md mx-auto z-40">
        <button 
          onClick={onConfirm}
          className="w-full h-16 bg-blue-600 text-white font-black text-lg rounded-2xl shadow-2xl shadow-blue-600/30 flex items-center justify-center gap-3 active:scale-95 transition-all"
        >
          <CheckCircle2 size={22} />
          {t('confirm_booking')}
        </button>
      </div>
    </div>
  );
};

const AdminDashboardScreen = ({ setScreen }: { setScreen: (s: Screen) => void }) => (
  <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-950">
    <header className="sticky top-0 z-10 flex items-center bg-white/80 dark:bg-slate-900/80 backdrop-blur-md p-4 justify-between border-b border-slate-200 dark:border-slate-800">
      <div className="flex items-center gap-3">
        <div className="bg-emerald-500/10 p-2 rounded-lg"><LayoutDashboard size={24} className="text-emerald-500" /></div>
        <div>
          <h1 className="text-lg font-bold">Admin Console</h1>
          <p className="text-xs text-slate-500">MTC Chennai Cloud</p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <button className="size-10 flex items-center justify-center rounded-full bg-slate-100 dark:bg-slate-800"><Bell size={20} /></button>
        <div className="size-10 overflow-hidden rounded-full border-2 border-emerald-500">
          <img src={getCDNImage('admin', 100, 100)} alt="Admin" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
        </div>
      </div>
    </header>
    <main className="p-4 space-y-6 pb-24 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-100 dark:border-slate-800 shadow-sm">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-slate-500 text-sm font-medium">Total Bookings</p>
            <p className="text-2xl font-bold mt-1">12,450</p>
          </div>
          <div className="flex items-center gap-1 text-emerald-500 text-xs font-bold bg-emerald-500/10 px-2 py-1 rounded-full">
            <TrendingUp size={12} />
            <span>12%</span>
          </div>
        </div>
        <div className="h-16 w-full mt-4 bg-emerald-500/5 rounded-lg flex items-end px-2 pb-2 gap-1">
          {[40, 60, 45, 80, 55, 90, 70].map((h, i) => (
            <div key={i} className="flex-1 bg-emerald-500/20 rounded-t-sm" style={{ height: `${h}%` }} />
          ))}
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-100 dark:border-slate-800 shadow-sm">
          <p className="text-slate-500 text-sm font-medium">Active Passes</p>
          <p className="text-xl font-bold">842</p>
          <p className="text-[10px] text-emerald-500 font-bold mt-1">+5% increase</p>
        </div>
        <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-100 dark:border-slate-800 shadow-sm">
          <p className="text-slate-500 text-sm font-medium">Revenue</p>
          <p className="text-xl font-bold">₹4.2L</p>
          <p className="text-[10px] text-emerald-500 font-bold mt-1">+8% weekly</p>
        </div>
      </div>
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold">Recent Activity</h2>
          <button onClick={() => setScreen('ADMIN_TICKETS')}><Filter size={20} className="text-slate-400" /></button>
        </div>
        <div className="space-y-3">
          {[
            { title: 'Single Ticket Sold', desc: 'Route 102 (Kelambakkam)', val: '₹25.00', time: '2 mins ago', icon: Ticket, color: 'text-blue-600', bg: 'bg-blue-600/10' },
            { title: 'Monthly Pass Issued', desc: 'User: Karthik R.', val: '₹1,000.00', time: '15 mins ago', icon: CreditCard, color: 'text-emerald-500', bg: 'bg-emerald-500/10' },
            { title: 'Payment Failed', desc: 'Route 21G (Broadway)', val: '₹18.00', time: '42 mins ago', icon: AlertCircle, color: 'text-orange-600', bg: 'bg-orange-600/10' }
          ].map((act, i) => (
            <div key={i} className="flex items-center gap-4 bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
              <div className={cn("size-12 rounded-full flex items-center justify-center", act.bg, act.color)}><act.icon size={20} /></div>
              <div className="flex-1">
                <p className="text-sm font-semibold">{act.title}</p>
                <p className="text-xs text-slate-500">{act.desc}</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-bold">{act.val}</p>
                <p className="text-[10px] text-slate-400 uppercase">{act.time}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </main>
  </div>
);

const AdminTicketsScreen = ({ setScreen }: { setScreen: (s: Screen) => void }) => (
  <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-950">
    <header className="flex items-center bg-white dark:bg-slate-900 p-4 pb-2 justify-between sticky top-0 z-10 border-b border-emerald-500/10">
      <div className="flex items-center gap-3">
        <button onClick={() => setScreen('ADMIN_DASHBOARD')} className="bg-emerald-500/10 p-2 rounded-lg"><ArrowLeft size={24} className="text-emerald-500" /></button>
        <h2 className="text-lg font-bold">Ticket Records</h2>
      </div>
      <div className="flex items-center gap-2">
        <button className="size-10 flex items-center justify-center rounded-full bg-emerald-500/10"><Bell size={20} /></button>
        <button className="size-10 flex items-center justify-center rounded-full bg-emerald-500/10"><User size={20} /></button>
      </div>
    </header>
    <div className="px-4 py-4 bg-white dark:bg-slate-900">
      <div className="flex items-center bg-slate-50 dark:bg-slate-800 rounded-xl px-4 py-3 border border-emerald-500/20">
        <Search size={20} className="text-slate-400 mr-3" />
        <input className="bg-transparent border-none focus:ring-0 w-full text-sm p-0" placeholder="Search Ticket ID or Passenger" />
      </div>
    </div>
    <div className="flex border-b border-emerald-500/10 px-4 gap-6 overflow-x-auto no-scrollbar bg-white dark:bg-slate-900">
      {['All Tickets', 'Active', 'Expired', 'Refunded'].map((tab, i) => (
        <button key={tab} className={cn("pb-3 pt-2 text-sm font-medium whitespace-nowrap", i === 0 ? "border-b-2 border-emerald-500 text-slate-900 dark:text-white font-bold" : "text-slate-500")}>
          {tab}
        </button>
      ))}
    </div>
    <main className="flex-1 overflow-y-auto p-4 space-y-3 pb-24">
      {[
        { id: 'TKT-982341', route: 'Chennai Central — Adyar', user: 'Rajesh Kumar', time: 'Oct 24, 09:15 AM', status: 'Active' },
        { id: 'TKT-982342', route: 'Tambaram — T. Nagar', user: 'Priya Lakshmi', time: 'Oct 24, 08:30 AM', status: 'Expired' },
        { id: 'TKT-982343', route: 'Guindy — Broadway', user: 'Suresh V.', time: 'Oct 24, 10:05 AM', status: 'Active' }
      ].map((tkt, i) => (
        <div key={i} className="bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border border-emerald-500/5 flex flex-col gap-3">
          <div className="flex justify-between items-start">
            <div className="flex gap-3">
              <div className="size-11 rounded-lg bg-emerald-500/20 flex items-center justify-center text-emerald-500"><Ticket size={20} /></div>
              <div>
                <p className="font-bold text-sm">{tkt.id}</p>
                <p className="text-slate-500 text-xs font-medium">{tkt.route}</p>
              </div>
            </div>
            <span className={cn("px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider", tkt.status === 'Active' ? "bg-emerald-500/20 text-emerald-500" : "bg-slate-100 text-slate-500")}>{tkt.status}</span>
          </div>
          <div className="flex justify-between items-end pt-2 border-t border-emerald-500/5">
            <div>
              <p className="text-slate-400 text-[10px] uppercase font-bold">Passenger</p>
              <p className="text-sm font-medium">{tkt.user}</p>
            </div>
            <div className="text-right">
              <p className="text-slate-400 text-[10px] uppercase font-bold">Date & Time</p>
              <p className="text-sm font-medium">{tkt.time}</p>
            </div>
          </div>
        </div>
      ))}
    </main>
    <button className="fixed right-6 bottom-24 size-14 bg-emerald-500 text-slate-900 rounded-full shadow-lg flex items-center justify-center border-4 border-white dark:border-slate-900">
      <Plus size={24} />
    </button>
  </div>
);

// --- Main App ---

export default function App() {
  const [screen, setScreen] = useState<Screen>('SPLASH');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [selectedBus, setSelectedBus] = useState<Bus | null>(null);
  const [tickets, setTickets] = useState<TicketType[]>([]);
  const { i18n } = useTranslation();

  useEffect(() => {
    // Splash screen timer
    if (screen === 'SPLASH') {
      const timer = setTimeout(() => {
        setScreen('LOGIN');
      }, 2500);
      return () => clearTimeout(timer);
    }
  }, [screen]);

  const handleLogin = (phoneNumber: string) => {
    // In a real app, this would trigger Firebase OTP
    setScreen('OTP_VERIFY');
    // For demo purposes, show the OTP in an alert or notification
    setTimeout(() => {
      alert("Demo Mode: Your OTP is 123456");
    }, 500);
  };

  const handleVerifyOTP = (otp: string) => {
    // Mock verification
    if (otp === '123456') {
      setIsLoggedIn(true);
      setUser({
        uid: 'user_' + Math.random().toString(36).substr(2, 9),
        phoneNumber: '+91 9876543210',
        displayName: 'Karthik Raja',
        language: i18n.language as 'en' | 'ta',
        createdAt: new Date().toISOString()
      });
      setScreen('DASHBOARD');
    } else {
      alert('Invalid OTP. Use 123456 for demo.');
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUser(null);
    setScreen('LOGIN');
  };

  const renderScreen = () => {
    switch (screen) {
      case 'SPLASH': return <SplashScreen />;
      case 'LOGIN': return <LoginScreen onLogin={handleLogin} />;
      case 'OTP_VERIFY': return <OTPVerifyScreen onVerify={handleVerifyOTP} onBack={() => setScreen('LOGIN')} />;
      case 'DASHBOARD': return <DashboardScreen setScreen={setScreen} user={user} />;
      case 'MY_PASS': return <MyPassScreen setScreen={setScreen} />;
      case 'LIVE_TRACKING': return <LiveTrackingScreen setScreen={setScreen} />;
      case 'PROFILE': return <ProfileScreen setScreen={setScreen} onLogout={handleLogout} user={user} />;
      case 'PAYMENT': return <PaymentScreen setScreen={setScreen} bus={selectedBus} />;
      case 'LANGUAGE': return <LanguageScreen setScreen={setScreen} />;
      case 'ARRIVALS': return <ArrivalsScreen setScreen={setScreen} />;
      case 'SPECIAL_PASSES': return <SpecialPassesScreen setScreen={setScreen} />;
      case 'MY_TICKETS': return <MyTicketsScreen setScreen={setScreen} tickets={tickets} />;
      case 'ROUTE_SEARCH': return <RouteSearchScreen setScreen={setScreen} />;
      case 'AVAILABLE_BUSES': return <AvailableBusesScreen setScreen={setScreen} onSelectBus={(bus) => { setSelectedBus(bus); setScreen('BOOKING_SUMMARY'); }} />;
      case 'BOOKING_SUMMARY': return <BookingSummaryScreen setScreen={setScreen} bus={selectedBus} onConfirm={() => {
        if (selectedBus && user) {
          const newTicket: TicketType = {
            id: 'TKT-' + Math.floor(100000 + Math.random() * 900000),
            userId: user.uid,
            busId: selectedBus.id,
            routeId: selectedBus.busNumber,
            passengerName: user.displayName || 'Passenger',
            busNumber: selectedBus.busNumber,
            routeName: selectedBus.routeName,
            from: selectedBus.from,
            to: selectedBus.to,
            fare: selectedBus.fare,
            travelDate: new Date().toLocaleDateString(),
            travelTime: selectedBus.departureTime,
            status: 'ACTIVE',
            qrCode: 'https://chennairide.app/verify/' + Math.random().toString(36).substr(2, 9),
            createdAt: new Date().toISOString()
          };
          setTickets([newTicket, ...tickets]);
          setScreen('MY_TICKETS');
        }
      }} />;
      case 'ADMIN_DASHBOARD': return <AdminDashboardScreen setScreen={setScreen} />;
      case 'ADMIN_TICKETS': return <AdminTicketsScreen setScreen={setScreen} />;
      default: return <DashboardScreen setScreen={setScreen} user={user} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 flex justify-center">
      <div className="relative w-full max-w-md bg-white dark:bg-slate-900 shadow-2xl overflow-hidden flex flex-col">
        <AnimatePresence mode="wait">
          <motion.div
            key={screen}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
            className="flex-1 overflow-hidden"
          >
            {renderScreen()}
          </motion.div>
        </AnimatePresence>
        
        {isLoggedIn && ['DASHBOARD', 'MY_TICKETS', 'LIVE_TRACKING', 'PROFILE'].includes(screen) && (
          <BottomNav currentScreen={screen} setScreen={setScreen} />
        )}
      </div>
    </div>
  );
}
