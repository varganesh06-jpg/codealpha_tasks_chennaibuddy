import { LucideIcon } from 'lucide-react';

export type Screen = 
  | 'login' 
  | 'home' 
  | 'search_results' 
  | 'confirm_booking' 
  | 'tickets' 
  | 'profile' 
  | 'tracking' 
  | 'admin' 
  | 'fare_calculator' 
  | 'pass_selection' 
  | 'pass_details'
  | 'pass_activation_success';

export interface BusRoute {
  id: string;
  number: string;
  type: 'Deluxe' | 'Express' | 'Normal' | 'Volvo AC';
  from: string;
  to: string;
  departure: string;
  arrival: string;
  duration: string;
  price: number;
  seatsLeft: number;
  stops: string[];
  status: 'On Time' | '5m Delay' | 'Heavy Crowd';
}

export interface Ticket {
  id: string;
  routeNumber: string;
  from: string;
  to: string;
  passengerName: string;
  busNumber: string;
  dateTime: string;
  price: number;
  status: 'Active' | 'Expired' | 'History';
}

export interface MonthlyPass {
  id: string;
  name: string;
  description: string;
  price: number;
  benefits: string[];
  isPremium?: boolean;
  tag?: string;
}
