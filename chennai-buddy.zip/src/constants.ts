import { BusRoute, Ticket, MonthlyPass } from './types';

export const SAMPLE_ROUTES: BusRoute[] = [
  {
    id: '1',
    number: '570',
    type: 'Deluxe',
    from: 'CMBT Terminal',
    to: 'Siruseri IT Park',
    departure: '09:30 AM',
    arrival: '10:45 AM',
    duration: '1h 15m',
    price: 45,
    seatsLeft: 12,
    stops: ['Koyambedu', 'Ashok Pillar', 'Guindy', 'OMR', 'Navalur'],
    status: 'On Time'
  },
  {
    id: '2',
    number: '21G',
    type: 'Express',
    from: 'Broadway',
    to: 'Tambaram',
    departure: '10:15 AM',
    arrival: '11:45 AM',
    duration: '1h 30m',
    price: 35,
    seatsLeft: 4,
    stops: ['Broadway', 'Central', 'Egmore', 'Chetpet', 'Kilpauk'],
    status: '5m Delay'
  },
  {
    id: '3',
    number: 'V51',
    type: 'Volvo AC',
    from: 'Tambaram',
    to: 'T. Nagar',
    departure: '11:00 AM',
    arrival: '12:05 PM',
    duration: '1h 05m',
    price: 85,
    seatsLeft: 22,
    stops: ['Tambaram', 'Chromepet', 'Pallavaram', 'Airport', 'Guindy'],
    status: 'On Time'
  }
];

export const SAMPLE_TICKETS: Ticket[] = [
  {
    id: 'CHN-8829410',
    routeNumber: '51G',
    from: 'Tambaram',
    to: 'Broadway',
    passengerName: 'Arjun Kumar',
    busNumber: 'MTC 51G',
    dateTime: '24 Oct, 10:45 AM',
    price: 25,
    status: 'Active'
  }
];

export const MONTHLY_PASSES: MonthlyPass[] = [
  {
    id: 'student',
    name: 'MTC Student Pass',
    description: 'Exclusive for School/College students',
    price: 250,
    tag: 'Best Value',
    benefits: [
      'Unlimited travel on Ordinary/Express routes',
      'Valid for 30 days from date of issue',
      'Digital identity verification required'
    ]
  },
  {
    id: 'regular',
    name: 'MTC Regular Monthly',
    description: 'All-access pass for daily commuters',
    price: 1000,
    benefits: [
      'Unlimited travel on all routes (Excl. AC)',
      'Free transfer between bus lines',
      'Valid across Chennai Metropolitan Area'
    ]
  },
  {
    id: 'premium',
    name: 'MTC AC Premium',
    description: 'Maximum comfort for your commute',
    price: 2500,
    isPremium: true,
    benefits: [
      'Unlimited travel on AC & Deluxe buses',
      'Priority boarding at select terminals',
      'Access to all MTC bus categories'
    ]
  }
];
