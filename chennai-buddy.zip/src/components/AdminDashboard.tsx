import { Bell, UserCircle, Search, TrendingUp, LayoutGrid, Ticket, Map as MapIcon, Settings } from 'lucide-react';
import { Screen } from '../types';

interface AdminDashboardProps {
  onNavigate: (screen: Screen) => void;
}

export default function AdminDashboard({ onNavigate }: AdminDashboardProps) {
  return (
    <div className="bg-background-light dark:bg-background-dark font-display text-slate-900 dark:text-slate-100 min-h-screen flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-primary p-2 rounded-lg text-white">
            <span className="material-symbols-outlined block">directions_bus</span>
          </div>
          <div>
            <h1 className="text-lg font-bold leading-tight tracking-tight">Chennai Buddy</h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">Admin Dashboard</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button className="text-slate-600 dark:text-slate-400 p-1">
            <Bell className="size-5" />
          </button>
          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20">
            <UserCircle className="text-primary size-6" />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto pb-24">
        {/* Search */}
        <div className="px-4 py-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 size-5" />
            <input 
              className="w-full pl-10 pr-4 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent outline-none text-sm transition-all" 
              placeholder="Search tickets, routes, or passengers..." 
              type="text"
            />
          </div>
        </div>

        {/* Metric Cards */}
        <div className="px-4 flex flex-col gap-4">
          <div className="grid grid-cols-1 gap-4">
            {/* Total Bookings */}
            <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="text-sm font-medium text-slate-500 dark:text-slate-400">Total Bookings</p>
                  <h3 className="text-2xl font-bold mt-1">1,284</h3>
                </div>
                <span className="text-xs font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/30 px-2 py-1 rounded-lg flex items-center gap-1">
                  <TrendingUp className="size-3" /> 12%
                </span>
              </div>
              <div className="h-12 w-full mt-2">
                <svg className="w-full h-full overflow-visible" viewBox="0 0 100 30">
                  <path d="M0,25 Q10,5 20,20 T40,15 T60,25 T80,10 T100,18" fill="none" stroke="#135bec" strokeLinecap="round" strokeWidth="2"></path>
                </svg>
              </div>
            </div>

            {/* Active Tickets */}
            <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="text-sm font-medium text-slate-500 dark:text-slate-400">Active Tickets</p>
                  <h3 className="text-2xl font-bold mt-1">450</h3>
                </div>
                <span className="text-xs font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/30 px-2 py-1 rounded-lg flex items-center gap-1">
                  <TrendingUp className="size-3" /> 5%
                </span>
              </div>
              <div className="h-12 w-full mt-2">
                <svg className="w-full h-full overflow-visible" viewBox="0 0 100 30">
                  <path d="M0,15 Q15,25 30,10 T60,20 T100,5" fill="none" stroke="#135bec" strokeLinecap="round" strokeWidth="2"></path>
                </svg>
              </div>
            </div>

            {/* Daily Revenue */}
            <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="text-sm font-medium text-slate-500 dark:text-slate-400">Daily Revenue</p>
                  <h3 className="text-2xl font-bold mt-1">₹42,500</h3>
                </div>
                <span className="text-xs font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/30 px-2 py-1 rounded-lg flex items-center gap-1">
                  <TrendingUp className="size-3" /> 8%
                </span>
              </div>
              <div className="h-12 w-full mt-2">
                <svg className="w-full h-full overflow-visible" viewBox="0 0 100 30">
                  <path d="M0,28 L20,22 L40,25 L60,10 L80,15 L100,2" fill="none" stroke="#135bec" strokeLinecap="round" strokeWidth="2"></path>
                </svg>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Records */}
        <div className="mt-8 px-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold">Recent Ticket Records</h2>
            <button className="text-primary text-sm font-semibold">View All</button>
          </div>
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {[
                { name: 'Rajesh Kumar', route: 'Tambaram - T.Nagar', status: 'Active', time: '2 mins ago', initial: 'RK' },
                { name: 'Ananya Priya', route: 'Adyar - OMR', status: 'Active', time: '10 mins ago', initial: 'AP' },
                { name: 'M. Selvam', route: 'Central - Koyambedu', status: 'Expired', time: '45 mins ago', initial: 'MS' },
                { name: 'Vignesh V.', route: 'Velachery - Guindy', status: 'Pending', time: '1 hr ago', initial: 'VV' },
              ].map((record, i) => (
                <div key={i} className="p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 font-bold text-xs">{record.initial}</div>
                    <div>
                      <p className="text-sm font-semibold">{record.name}</p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">Route: {record.route}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className={`inline-block px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      record.status === 'Active' ? 'bg-emerald-100 text-emerald-700' : 
                      record.status === 'Pending' ? 'bg-amber-100 text-amber-700' : 
                      'bg-slate-100 text-slate-600'
                    }`}>
                      {record.status}
                    </span>
                    <p className="text-xs mt-1 text-slate-400">{record.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>

      {/* Bottom Nav */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white/95 dark:bg-background-dark/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 pb-8">
        <div className="flex justify-around items-center px-2 py-3">
          <button onClick={() => onNavigate('admin')} className="flex flex-col items-center gap-1 text-primary">
            <LayoutGrid className="size-6" style={{ fontVariationSettings: "'FILL' 1" }} />
            <span className="text-[10px] font-bold tracking-tight">Dashboard</span>
          </button>
          <button onClick={() => onNavigate('tickets')} className="flex flex-col items-center gap-1 text-slate-400">
            <Ticket className="size-6" />
            <span className="text-[10px] font-medium tracking-tight">Tickets</span>
          </button>
          <button onClick={() => onNavigate('home')} className="flex flex-col items-center gap-1 text-slate-400">
            <MapIcon className="size-6" />
            <span className="text-[10px] font-medium tracking-tight">Routes</span>
          </button>
          <button onClick={() => onNavigate('profile')} className="flex flex-col items-center gap-1 text-slate-400">
            <Settings className="size-6" />
            <span className="text-[10px] font-medium tracking-tight">Settings</span>
          </button>
        </div>
      </nav>
    </div>
  );
}
