import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Smartphone, Lock, ArrowRight, Chrome, MessageSquare, Bus, MapPin, Users } from 'lucide-react';
import { Logo } from './Logo';

interface LoginScreenProps {
  onLogin: () => void;
}

export default function LoginScreen({ onLogin }: LoginScreenProps) {
  const [mobileNumber, setMobileNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [showOtpInput, setShowOtpInput] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  // Google OAuth Popup Flow
  const handleGoogleLogin = async () => {
    try {
      const response = await fetch('/api/auth/google/url');
      const { url } = await response.json();
      
      const width = 500;
      const height = 600;
      const left = window.screenX + (window.outerWidth - width) / 2;
      const top = window.screenY + (window.outerHeight - height) / 2;
      
      const popup = window.open(
        url,
        'google_login',
        `width=${width},height=${height},left=${left},top=${top}`
      );

      if (!popup) {
        alert('Please allow popups to sign in with Google');
      }
    } catch (err) {
      console.error('Google login error:', err);
      setError('Failed to start Google login');
    }
  };

  // Listen for OAuth success
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'OAUTH_AUTH_SUCCESS') {
        onLogin();
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [onLogin]);

  const handleSendOtp = async () => {
    if (!mobileNumber || mobileNumber.length < 10) {
      setError('Please enter a valid mobile number');
      return;
    }
    setIsLoading(true);
    setError('');
    try {
      const res = await fetch('/api/auth/otp/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: mobileNumber }),
      });
      const data = await res.json();
      if (data.success) {
        setShowOtpInput(true);
        setSuccessMessage('OTP sent! Use 123456 for this demo.');
      } else {
        setError(data.error || 'Failed to send OTP');
      }
    } catch (err) {
      setError('Connection error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyOtp = async () => {
    if (!otp || otp.length < 6) {
      setError('Please enter the 6-digit OTP');
      return;
    }
    setIsLoading(true);
    setError('');
    try {
      const res = await fetch('/api/auth/otp/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: mobileNumber, otp }),
      });
      const data = await res.json();
      if (data.success) {
        onLogin();
      } else {
        setError(data.error || 'Invalid OTP');
      }
    } catch (err) {
      setError('Connection error');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="relative flex flex-col min-h-screen bg-white dark:bg-slate-950 overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
        {/* Moving Clouds */}
        <motion.div 
          animate={{ x: ['-20%', '100%'] }}
          transition={{ duration: 60, repeat: Infinity, ease: 'linear' }}
          className="absolute top-10 left-0 opacity-20 dark:opacity-10"
        >
          <div className="flex gap-40">
            <div className="w-32 h-12 bg-slate-200 dark:bg-slate-700 rounded-full blur-xl"></div>
            <div className="w-48 h-16 bg-slate-200 dark:bg-slate-700 rounded-full blur-xl"></div>
          </div>
        </motion.div>

        {/* Moving Bus Animation */}
        <motion.div 
          animate={{ x: ['-100%', '100vw'] }}
          transition={{ duration: 15, repeat: Infinity, ease: 'linear' }}
          className="absolute bottom-32 left-0 z-0 opacity-30 flex items-center gap-2"
        >
          <div className="bg-primary p-3 rounded-xl shadow-lg">
            <Bus className="size-8 text-white" />
          </div>
          <div className="h-1 w-20 bg-slate-200 dark:bg-slate-800 rounded-full"></div>
        </motion.div>

        {/* Chennai Themed Images Float */}
        <div className="absolute inset-0 opacity-5 dark:opacity-10">
          <motion.div 
            animate={{ y: [0, -20, 0] }}
            transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute top-20 left-10 w-40 h-40 rounded-3xl overflow-hidden rotate-12"
          >
            <img src="https://picsum.photos/seed/chennai-city/400/400" className="w-full h-full object-cover" alt="Chennai" referrerPolicy="no-referrer" />
          </motion.div>
          <motion.div 
            animate={{ y: [0, 20, 0] }}
            transition={{ duration: 12, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute bottom-40 right-10 w-48 h-48 rounded-3xl overflow-hidden -rotate-12"
          >
            <img src="https://picsum.photos/seed/chennai-commute/400/400" className="w-full h-full object-cover" alt="Commute" referrerPolicy="no-referrer" />
          </motion.div>
        </div>
      </div>

      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="relative z-10 flex-1 flex flex-col justify-center p-8"
      >
        <div className="mb-12 flex flex-col items-center">
          <motion.div
            initial={{ scale: 0.5, rotate: -10 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: "spring", stiffness: 260, damping: 20 }}
            className="relative"
          >
            <Logo className="size-24 mb-6" />
            <motion.div
              animate={{ x: [0, 5, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="absolute -right-4 top-0 bg-primary text-white p-1 rounded-full shadow-lg"
            >
              <Bus className="size-4" />
            </motion.div>
          </motion.div>
          <h1 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight text-center">Chennai Buddy</h1>
          <p className="text-slate-500 dark:text-slate-400 mt-2 text-center font-medium">Your smart companion for<br/>city transit</p>
        </div>

        <div className="space-y-6">
          <AnimatePresence mode="wait">
            {!showOtpInput ? (
              <motion.div 
                key="phone-input"
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: 20, opacity: 0 }}
                className="space-y-4"
              >
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest font-bold text-slate-400 ml-1">Mobile Number</label>
                  <div className="flex items-center gap-3 bg-slate-50 dark:bg-slate-900 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 focus-within:border-primary focus-within:ring-1 focus-within:ring-primary transition-all">
                    <Smartphone className="text-slate-400 size-5" />
                    <input 
                      type="tel" 
                      placeholder="Enter your mobile number"
                      className="bg-transparent border-none p-0 focus:ring-0 text-slate-900 dark:text-white font-bold w-full outline-none"
                      value={mobileNumber}
                      onChange={(e) => setMobileNumber(e.target.value)}
                    />
                  </div>
                </div>

                {error && <p className="text-red-500 text-xs font-bold ml-1">{error}</p>}

                <motion.button 
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleSendOtp}
                  disabled={isLoading}
                  className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-4 rounded-2xl shadow-xl shadow-primary/30 transition-all flex items-center justify-center gap-2 group disabled:opacity-50"
                >
                  {isLoading ? 'Sending...' : 'Send OTP'}
                  <ArrowRight className="size-5 group-hover:translate-x-1 transition-transform" />
                </motion.button>
              </motion.div>
            ) : (
              <motion.div 
                key="otp-input"
                initial={{ x: 20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: -20, opacity: 0 }}
                className="space-y-4"
              >
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest font-bold text-slate-400 ml-1">Enter 6-Digit OTP</label>
                  <div className="flex items-center gap-3 bg-slate-50 dark:bg-slate-900 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 focus-within:border-primary focus-within:ring-1 focus-within:ring-primary transition-all">
                    <MessageSquare className="text-slate-400 size-5" />
                    <input 
                      type="text" 
                      maxLength={6}
                      placeholder="000000"
                      className="bg-transparent border-none p-0 focus:ring-0 text-slate-900 dark:text-white font-bold w-full outline-none tracking-[0.5em]"
                      value={otp}
                      onChange={(e) => setOtp(e.target.value)}
                    />
                  </div>
                </div>

                {error && <p className="text-red-500 text-xs font-bold ml-1">{error}</p>}
                {successMessage && <p className="text-emerald-500 text-xs font-bold ml-1">{successMessage}</p>}

                <div className="flex gap-3">
                  <button 
                    onClick={() => setShowOtpInput(false)}
                    className="flex-1 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold py-4 rounded-2xl"
                  >
                    Back
                  </button>
                  <motion.button 
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={handleVerifyOtp}
                    disabled={isLoading}
                    className="flex-[2] bg-primary hover:bg-primary/90 text-white font-bold py-4 rounded-2xl shadow-xl shadow-primary/30 transition-all flex items-center justify-center gap-2 group disabled:opacity-50"
                  >
                    {isLoading ? 'Verifying...' : 'Verify & Login'}
                    <ArrowRight className="size-5 group-hover:translate-x-1 transition-transform" />
                  </motion.button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="mt-12">
          <div className="relative flex items-center justify-center mb-8">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-100 dark:border-slate-800"></div>
            </div>
            <span className="relative px-4 bg-white dark:bg-slate-950 text-[10px] uppercase tracking-widest font-bold text-slate-400">Or continue with</span>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <motion.button 
              whileHover={{ y: -2 }}
              onClick={handleGoogleLogin}
              className="flex items-center justify-center gap-3 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors"
            >
              <Chrome className="size-5 text-red-500" />
              <span className="text-sm font-bold">Google</span>
            </motion.button>
            <motion.button 
              whileHover={{ y: -2 }}
              className="flex items-center justify-center gap-3 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors"
            >
              <Smartphone className="size-5 text-slate-900 dark:text-white" />
              <span className="text-sm font-bold">Apple</span>
            </motion.button>
          </div>
        </div>

        <div className="mt-8 flex justify-center gap-8 opacity-40">
          <div className="flex flex-col items-center gap-1">
            <Bus className="size-4" />
            <span className="text-[8px] font-bold uppercase">Buses</span>
          </div>
          <div className="flex flex-col items-center gap-1">
            <MapPin className="size-4" />
            <span className="text-[8px] font-bold uppercase">Live</span>
          </div>
          <div className="flex flex-col items-center gap-1">
            <Users className="size-4" />
            <span className="text-[8px] font-bold uppercase">People</span>
          </div>
        </div>
      </motion.div>

      <motion.p 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="text-center text-[10px] text-slate-400 mt-8 mb-8 font-medium relative z-10"
      >
        By continuing, you agree to our<br/>
        <span className="underline">Terms of Service</span> and <span className="underline">Privacy Policy</span>
      </motion.p>
    </div>
  );
}
