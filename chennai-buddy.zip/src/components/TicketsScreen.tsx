import { useState, useEffect } from 'react';
import { ArrowLeft, RefreshCw, Home, Ticket, Route, User, Camera, X } from 'lucide-react';
import { Html5QrcodeScanner } from 'html5-qrcode';
import { SAMPLE_TICKETS } from '../constants';
import { Screen } from '../types';

interface TicketsScreenProps {
  onNavigate: (screen: Screen) => void;
}

export default function TicketsScreen({ onNavigate }: TicketsScreenProps) {
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState<string | null>(null);
  const ticket = SAMPLE_TICKETS[0];

  useEffect(() => {
    let scanner: Html5QrcodeScanner | null = null;
    if (isScanning) {
      scanner = new Html5QrcodeScanner(
        "reader",
        { fps: 10, qrbox: { width: 250, height: 250 } },
        /* verbose= */ false
      );
      scanner.render(
        (decodedText) => {
          setScanResult(decodedText);
          setIsScanning(false);
          if (scanner) scanner.clear();
        },
        (error) => {
          // console.warn(error);
        }
      );
    }
    return () => {
      if (scanner) {
        scanner.clear().catch(error => console.error("Failed to clear scanner", error));
      }
    };
  }, [isScanning]);

  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-background-dark">
      {/* Scanner Modal */}
      {isScanning && (
        <div className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center p-6">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-2xl overflow-hidden relative">
            <button 
              onClick={() => setIsScanning(false)}
              className="absolute top-4 right-4 z-10 p-2 bg-black/50 text-white rounded-full"
            >
              <X className="size-6" />
            </button>
            <div className="p-6 text-center">
              <h3 className="text-lg font-bold mb-2">Scan Ticket QR</h3>
              <p className="text-sm text-slate-500 mb-6">Position the QR code within the frame to validate</p>
              <div id="reader" className="w-full aspect-square bg-slate-100 rounded-xl overflow-hidden"></div>
            </div>
          </div>
        </div>
      )}

      {/* Scan Success Toast */}
      {scanResult && (
        <div className="fixed top-20 left-4 right-4 z-50 bg-emerald-500 text-white p-4 rounded-xl shadow-2xl flex items-center justify-between animate-bounce">
          <div className="flex items-center gap-3">
            <div className="size-8 bg-white/20 rounded-full flex items-center justify-center">
              <span className="material-symbols-outlined text-sm">check</span>
            </div>
            <div>
              <p className="text-sm font-bold">Ticket Validated!</p>
              <p className="text-[10px] opacity-80">ID: {scanResult}</p>
            </div>
          </div>
          <button onClick={() => setScanResult(null)} className="text-white/60">
            <X className="size-4" />
          </button>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center p-4 pt-6 justify-between sticky top-0 bg-background-light/80 backdrop-blur-md z-10">
        <button 
          onClick={() => onNavigate('home')}
          className="text-slate-900 dark:text-slate-100 flex size-10 items-center justify-center rounded-full hover:bg-primary/10"
        >
          <ArrowLeft className="size-6" />
        </button>
        <h2 className="text-lg font-bold leading-tight tracking-tight flex-1 text-center">My Digital Tickets</h2>
        <div className="w-10"></div>
      </div>

      {/* Tabs */}
      <div className="px-4">
        <div className="flex border-b border-slate-200 dark:border-slate-800 gap-8">
          <button className="flex flex-col items-center justify-center border-b-[3px] border-primary text-primary pb-3 pt-2">
            <p className="text-sm font-bold leading-normal">Active</p>
          </button>
          <button className="flex flex-col items-center justify-center border-b-[3px] border-transparent text-slate-500 pb-3 pt-2">
            <p className="text-sm font-bold leading-normal">History</p>
          </button>
          <button className="flex flex-col items-center justify-center border-b-[3px] border-transparent text-slate-500 pb-3 pt-2">
            <p className="text-sm font-bold leading-normal">Passes</p>
          </button>
        </div>
      </div>

      {/* Ticket Container */}
      <div className="flex-1 p-4 flex flex-col gap-6">
        <div className="relative bg-white dark:bg-slate-900 rounded-xl shadow-lg border border-slate-100 dark:border-slate-800 flex flex-col">
          {/* Ticket Header */}
          <div className="p-5">
            <div className="flex justify-between items-start mb-4">
              <div className="flex flex-col">
                <span className="text-[10px] font-extrabold uppercase tracking-widest text-primary/70">Chennai Buddy Ticket</span>
                <h3 className="text-xl font-extrabold mt-1">{ticket.from} to {ticket.to}</h3>
              </div>
              <span className="bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400 text-[10px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1">
                <span className="size-1.5 bg-green-500 rounded-full"></span> ACTIVE
              </span>
            </div>
            <div className="grid grid-cols-2 gap-y-4 gap-x-2 mt-4">
              <div>
                <p className="text-[11px] text-slate-400 uppercase font-semibold">Passenger</p>
                <p className="text-sm font-bold">{ticket.passengerName}</p>
              </div>
              <div className="text-right">
                <p className="text-[11px] text-slate-400 uppercase font-semibold">Bus Number</p>
                <p className="text-sm font-bold">{ticket.busNumber}</p>
              </div>
              <div>
                <p className="text-[11px] text-slate-400 uppercase font-semibold">Ticket ID</p>
                <p className="text-sm font-bold">{ticket.id}</p>
              </div>
              <div className="text-right">
                <p className="text-[11px] text-slate-400 uppercase font-semibold">Date & Time</p>
                <p className="text-sm font-bold">{ticket.dateTime}</p>
              </div>
            </div>
          </div>

          {/* Perforation UI */}
          <div className="relative h-6 flex items-center overflow-hidden">
            <div className="absolute -left-3 size-6 rounded-full bg-background-light dark:bg-background-dark border border-slate-100 dark:border-slate-800"></div>
            <div className="w-full border-t border-dashed border-slate-200 dark:border-slate-700 mx-4"></div>
            <div className="absolute -right-3 size-6 rounded-full bg-background-light dark:bg-background-dark border border-slate-100 dark:border-slate-800"></div>
          </div>

          {/* QR Code Section */}
          <div className="p-6 flex flex-col items-center justify-center gap-4">
            <div className="p-3 bg-white rounded-lg shadow-inner border border-slate-100">
              <div className="size-48 bg-slate-100 rounded flex items-center justify-center relative overflow-hidden group">
                <img 
                  alt="Digital QR Code for ticket validation" 
                  className="w-full h-full object-contain" 
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuBNh4FZj4JUVx9ZWrhUs7FRJHs6ObU6_i4EWvogrY-WuazvWxVP0txqZtLdaDNw1_l8ePtuZyjBhA1lde0av6b48lCKdXlWdoWxnED2g6E2RBIPONKsRHYXcjUcw3tq04djulshy2qh4EdygnR7r5xb_WFUwkpZjLGSkhA1YyMBMtP9EVpPUIo8fr0JvNWBQqnLd7FT-lyDdEBIvLf4uW1r8TELPJiN5YwGH2gRdkAf-CLD3WWC8Rxt5NhIP_HN18a2XbRlMbQQw4hR"
                />
                <div className="absolute inset-0 bg-primary/5 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <RefreshCw className="text-primary size-10" />
                </div>
              </div>
            </div>
            <div className="flex flex-col items-center gap-2">
              <p className="text-xs text-slate-400 font-medium italic">Scan at the conductor's terminal</p>
              <button 
                onClick={() => setIsScanning(true)}
                className="flex items-center gap-2 text-primary text-xs font-bold bg-primary/10 px-4 py-2 rounded-full hover:bg-primary/20 transition-colors"
              >
                <Camera className="size-4" />
                Scan to Validate
              </button>
            </div>
          </div>

          {/* Footer Action */}
          <div className="px-5 pb-5">
            <button 
              onClick={() => onNavigate('tracking')}
              className="w-full bg-primary text-white font-bold py-3 rounded-lg hover:bg-primary/90 transition-colors shadow-md shadow-primary/20"
            >
              View Detailed Route
            </button>
          </div>
        </div>

        {/* Fare Summary */}
        <div className="bg-primary/5 dark:bg-primary/10 rounded-xl p-4 border border-primary/10">
          <div className="flex justify-between items-center mb-2">
            <p className="text-sm text-slate-600 dark:text-slate-400 font-medium">Ticket Fare</p>
            <p className="text-lg font-bold text-primary">₹{ticket.price.toFixed(2)}</p>
          </div>
          <div className="flex justify-between items-center">
            <p className="text-xs text-slate-500 dark:text-slate-500">Payment via Cloud Wallet</p>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">Transaction #TRX-9901</p>
          </div>
        </div>
      </div>

      {/* Bottom Nav */}
      <div className="mt-auto border-t border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md px-4 pb-6 pt-2">
        <div className="flex justify-between items-center">
          <button onClick={() => onNavigate('home')} className="flex flex-1 flex-col items-center gap-1 text-slate-400">
            <Home className="size-6" />
            <p className="text-[10px] font-bold leading-normal">Home</p>
          </button>
          <button onClick={() => onNavigate('tickets')} className="flex flex-1 flex-col items-center gap-1 text-primary">
            <Ticket className="size-6" />
            <p className="text-[10px] font-bold leading-normal">My Tickets</p>
          </button>
          <button onClick={() => onNavigate('home')} className="flex flex-1 flex-col items-center gap-1 text-slate-400">
            <Route className="size-6" />
            <p className="text-[10px] font-bold leading-normal">Routes</p>
          </button>
          <button onClick={() => onNavigate('profile')} className="flex flex-1 flex-col items-center gap-1 text-slate-400">
            <User className="size-6" />
            <p className="text-[10px] font-bold leading-normal">Profile</p>
          </button>
        </div>
      </div>
    </div>
  );
}
