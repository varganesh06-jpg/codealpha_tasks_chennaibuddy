import { motion } from 'motion/react';
import { MapPin, Navigation, Calendar, Users, Search, TrendingUp, History, Star, Map as MapIcon, Home, Ticket, Wallet, User, ArrowUpDown, ArrowRight, Bell, Zap, Bus } from 'lucide-react';
import { Screen } from '../types';
import { Logo } from './Logo';

interface HomeScreenProps {
  onNavigate: (screen: Screen) => void;
}

export default function HomeScreen({ onNavigate }: HomeScreenProps) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="flex flex-col min-h-screen pb-24"
    >
      {/* Header */}
      <header className="bg-primary pt-12 pb-24 px-6 rounded-b-[2.5rem] shadow-lg relative overflow-hidden">
        {/* Animated Background Elements */}
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
          className="absolute -top-20 -right-20 w-64 h-64 bg-white/10 rounded-full blur-3xl"
        ></motion.div>
        <motion.div 
          animate={{ x: ['-100%', '100vw'] }}
          transition={{ duration: 10, repeat: Infinity, ease: 'linear' }}
          className="absolute bottom-4 left-0 opacity-20 z-0"
        >
          <Bus className="size-16 text-white" />
        </motion.div>

        <div className="flex justify-between items-center mb-6 relative z-10">
          <div className="flex items-center gap-3">
            <Logo className="size-12" />
            <div>
              <h1 className="text-white text-xl font-bold leading-none">Chennai Buddy</h1>
              <p className="text-white/70 text-[10px] mt-1 uppercase tracking-widest font-bold">Smart Cloud Transit</p>
            </div>
          </div>
          <motion.button 
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center backdrop-blur-md"
          >
            <Bell className="text-white size-5" />
          </motion.button>
        </div>
        <motion.div variants={itemVariants} className="mt-4 relative z-10">
          <h2 className="text-white text-2xl font-semibold leading-tight">Where are you<br/>heading today?</h2>
        </motion.div>
      </header>

      {/* Search Card */}
      <motion.div variants={itemVariants} className="px-6 -mt-16 z-10">
        <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl p-6 border border-slate-100 dark:border-slate-800">
          <div className="space-y-4 relative">
            {/* From Field */}
            <div className="relative">
              <label className="text-[10px] uppercase tracking-wider font-bold text-slate-400 dark:text-slate-500 ml-1 mb-1 block">From</label>
              <div className="flex items-center gap-3 bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
                <MapPin className="text-primary size-5" />
                <input 
                  className="bg-transparent border-none p-0 focus:ring-0 text-slate-900 dark:text-slate-100 font-medium w-full outline-none" 
                  placeholder="Start location" 
                  type="text" 
                  defaultValue="Koyambedu (CMBT)"
                />
              </div>
            </div>

            {/* Swap Button */}
            <div className="absolute right-8 top-[50%] -translate-y-1/2 z-10">
              <motion.button 
                whileHover={{ rotate: 180 }}
                whileTap={{ scale: 0.9 }}
                className="w-10 h-10 bg-primary text-white rounded-full shadow-lg flex items-center justify-center border-4 border-white dark:border-slate-900 transition-transform"
              >
                <ArrowUpDown className="size-5" />
              </motion.button>
            </div>

            {/* To Field */}
            <div className="relative">
              <label className="text-[10px] uppercase tracking-wider font-bold text-slate-400 dark:text-slate-500 ml-1 mb-1 block">To</label>
              <div className="flex items-center gap-3 bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
                <Navigation className="text-rose-500 size-5" />
                <input 
                  className="bg-transparent border-none p-0 focus:ring-0 text-slate-900 dark:text-slate-100 font-medium w-full outline-none" 
                  placeholder="Destination" 
                  type="text" 
                  defaultValue="Adyar"
                />
              </div>
            </div>

            {/* Date & Passengers */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] uppercase tracking-wider font-bold text-slate-400 dark:text-slate-500 ml-1 mb-1 block">Travel Date</label>
                <div className="flex items-center gap-3 bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
                  <Calendar className="text-primary/60 size-5" />
                  <span className="text-sm font-medium">Today</span>
                </div>
              </div>
              <div>
                <label className="text-[10px] uppercase tracking-wider font-bold text-slate-400 dark:text-slate-500 ml-1 mb-1 block">Tickets</label>
                <div className="flex items-center gap-3 bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
                  <Users className="text-primary/60 size-5" />
                  <span className="text-sm font-medium">1 Ticket</span>
                </div>
              </div>
            </div>

            {/* Search Button */}
            <motion.button 
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onNavigate('search_results')}
              className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-4 rounded-xl shadow-lg shadow-primary/30 transition-all flex items-center justify-center gap-2 mt-4"
            >
              <Search className="size-5" />
              Search Buses
            </motion.button>
          </div>
        </div>
      </motion.div>

      {/* Live Updates Ticker */}
      <motion.div variants={itemVariants} className="px-6 mt-6">
        <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-3 flex items-center gap-3">
          <div className="size-8 bg-emerald-500 rounded-lg flex items-center justify-center shrink-0">
            <Zap className="text-white size-4 animate-pulse" />
          </div>
          <div className="overflow-hidden">
            <p className="text-[10px] font-bold text-emerald-600 uppercase tracking-wider">Live Update</p>
            <p className="text-xs font-medium text-slate-700 dark:text-slate-300 truncate">Bus 29C is arriving at Teynampet in 4 mins</p>
          </div>
        </div>
      </motion.div>

      {/* Frequent Routes Section */}
      <div className="px-6 mt-8">
        <motion.div variants={itemVariants} className="flex justify-between items-center mb-4">
          <h3 className="font-bold text-slate-800 dark:text-slate-200">Frequent Routes</h3>
          <button className="text-primary text-xs font-semibold">See All</button>
        </motion.div>
        <div className="space-y-3">
          {/* Route Card 1 */}
          <motion.div 
            variants={itemVariants}
            whileHover={{ x: 5 }}
            onClick={() => onNavigate('tracking')}
            className="bg-white dark:bg-slate-900 p-4 rounded-xl flex items-center justify-between border border-slate-100 dark:border-slate-800 shadow-sm cursor-pointer hover:bg-slate-50 transition-colors"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-primary/10 dark:bg-primary/20 rounded-lg flex items-center justify-center">
                <TrendingUp className="text-primary size-6" />
              </div>
              <div>
                <div className="flex items-center gap-2 text-sm font-bold text-slate-800 dark:text-slate-200">
                  <span>T. Nagar</span>
                  <ArrowRight className="size-3 text-slate-400" />
                  <span>Velachery</span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Next bus in 5 mins • Route 19B</p>
              </div>
            </div>
            <ArrowRight className="text-slate-300 size-5" />
          </motion.div>
          {/* Route Card 2 */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl flex items-center justify-between border border-slate-100 dark:border-slate-800 shadow-sm cursor-pointer hover:bg-slate-50 transition-colors">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-primary/10 dark:bg-primary/20 rounded-lg flex items-center justify-center">
                <History className="text-primary size-6" />
              </div>
              <div>
                <div className="flex items-center gap-2 text-sm font-bold text-slate-800 dark:text-slate-200">
                  <span>Broadway</span>
                  <ArrowRight className="size-3 text-slate-400" />
                  <span>Tambaram</span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Frequent • Route 1A</p>
              </div>
            </div>
            <span className="material-symbols-outlined text-slate-300">chevron_right</span>
          </div>
          {/* Route Card 3 */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl flex items-center justify-between border border-slate-100 dark:border-slate-800 shadow-sm cursor-pointer hover:bg-slate-50 transition-colors">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-primary/10 dark:bg-primary/20 rounded-lg flex items-center justify-center">
                <Star className="text-primary size-6" />
              </div>
              <div>
                <div className="flex items-center gap-2 text-sm font-bold text-slate-800 dark:text-slate-200">
                  <span>Chromepet</span>
                  <ArrowRight className="size-3 text-slate-400" />
                  <span>Anna Nagar</span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Deluxe • Route 70</p>
              </div>
            </div>
            <span className="material-symbols-outlined text-slate-300">chevron_right</span>
          </div>
        </div>
      </div>

      {/* Map Quick Look */}
      <div className="px-6 mt-8 mb-8">
        <div className="relative h-32 w-full rounded-2xl overflow-hidden shadow-inner bg-slate-200 dark:bg-slate-800">
          <img 
            className="w-full h-full object-cover opacity-50 dark:opacity-30" 
            alt="Abstract map of city bus routes" 
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuDOf9BGtVakjbD4tTgkkSoqPcrwDtg2jH6LOfP7MhJD-sgf6R2k0SLfuJHPa4339m_SNX_r07xdefyZ-KfLlNv45cn82D4q1-_9KDw9iH1GDy81NIbQ1yTTIy_chW5z_3twdKwTftFPribQO4V-ABjfwUtRvqTMbpoXQcUsfHd6dsdP3U0RtgxNcU3eQIzgIUiuekAEt9ssCjmW8i8jxu8TmmbFnDvF-DYlv2cLZ9fIoIBUw3LTss2EbWqp--KK9f9WS9aHjULC97nV"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 to-transparent flex items-end p-4">
            <button 
              onClick={() => onNavigate('tracking')}
              className="bg-white dark:bg-slate-900 text-slate-800 dark:text-white px-4 py-2 rounded-lg text-xs font-bold shadow-lg flex items-center gap-2 active:scale-95 transition-transform"
            >
              <MapIcon className="size-4" />
              View Route Map
            </button>
          </div>
        </div>
      </div>

      {/* Discover Chennai Section */}
      <div className="px-6 mt-8">
        <motion.div variants={itemVariants} className="flex justify-between items-center mb-4">
          <h3 className="font-bold text-slate-800 dark:text-slate-200">Discover Chennai</h3>
        </motion.div>
        <div className="flex gap-4 overflow-x-auto no-scrollbar pb-4">
          <motion.div 
            whileHover={{ scale: 1.05 }}
            className="shrink-0 w-48 h-32 rounded-2xl overflow-hidden relative shadow-md"
          >
            <img src="https://picsum.photos/seed/chennai-marina/400/300" className="w-full h-full object-cover" alt="Marina Beach" referrerPolicy="no-referrer" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-3">
              <span className="text-white text-[10px] font-bold">Marina Beach</span>
            </div>
          </motion.div>
          <motion.div 
            whileHover={{ scale: 1.05 }}
            className="shrink-0 w-48 h-32 rounded-2xl overflow-hidden relative shadow-md"
          >
            <img src="https://picsum.photos/seed/chennai-temple/400/300" className="w-full h-full object-cover" alt="Kapaleeshwarar Temple" referrerPolicy="no-referrer" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-3">
              <span className="text-white text-[10px] font-bold">Kapaleeshwarar Temple</span>
            </div>
          </motion.div>
          <motion.div 
            whileHover={{ scale: 1.05 }}
            className="shrink-0 w-48 h-32 rounded-2xl overflow-hidden relative shadow-md"
          >
            <img src="https://picsum.photos/seed/chennai-bus-stop/400/300" className="w-full h-full object-cover" alt="Chennai Commute" referrerPolicy="no-referrer" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-3">
              <span className="text-white text-[10px] font-bold">City Commute</span>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl border-t border-slate-200 dark:border-slate-800 px-6 pt-3 pb-8 max-w-md mx-auto z-20">
        <div className="flex justify-between items-center">
          <button onClick={() => onNavigate('home')} className="flex flex-col items-center gap-1 text-primary">
            <Home className="size-6" />
            <span className="text-[10px] font-bold">Home</span>
          </button>
          <button onClick={() => onNavigate('pass_selection')} className="flex flex-col items-center gap-1 text-slate-400">
            <Ticket className="size-6" />
            <span className="text-[10px] font-medium">Passes</span>
          </button>
          <button onClick={() => onNavigate('fare_calculator')} className="flex flex-col items-center gap-1 text-slate-400">
            <Wallet className="size-6" />
            <span className="text-[10px] font-medium">Fare</span>
          </button>
          <button onClick={() => onNavigate('profile')} className="flex flex-col items-center gap-1 text-slate-400">
            <User className="size-6" />
            <span className="text-[10px] font-medium">Profile</span>
          </button>
        </div>
      </nav>
    </motion.div>
  );
}
