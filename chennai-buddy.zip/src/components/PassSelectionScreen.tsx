import { ArrowLeft, Bus, CheckCircle, UserCheck, Calendar, Home, Ticket, Route, User } from 'lucide-react';
import { MONTHLY_PASSES } from '../constants';

interface PassSelectionScreenProps {
  onBack: () => void;
  onSelect: () => void;
}

export default function PassSelectionScreen({ onBack, onSelect }: PassSelectionScreenProps) {
  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-background-dark pb-24">
      <header className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md px-6 py-4 flex items-center justify-between border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <button 
            onClick={onBack}
            className="p-2 -ml-2 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-full transition-colors"
          >
            <ArrowLeft className="size-6" />
          </button>
          <h1 className="text-xl font-bold tracking-tight">Select Monthly Pass</h1>
        </div>
        <div className="text-primary flex size-10 shrink-0 items-center justify-center bg-primary/10 rounded-lg">
          <Bus className="size-6" />
        </div>
      </header>

      <main className="flex-1 px-4 py-6 space-y-6">
        {MONTHLY_PASSES.map((pass) => (
          <div 
            key={pass.id}
            className={`bg-white dark:bg-slate-900 rounded-2xl border overflow-hidden shadow-sm relative ${pass.isPremium ? 'border-2 border-primary' : 'border-slate-200 dark:border-slate-800'}`}
          >
            {pass.isPremium && (
              <div className="absolute top-0 right-0">
                <div className="bg-primary text-white text-[10px] font-black px-3 py-1 rounded-bl-lg uppercase">Premium</div>
              </div>
            )}
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div className="space-y-1">
                  {pass.tag && (
                    <span className="px-2.5 py-1 bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 text-[10px] font-bold uppercase tracking-wider rounded-md">{pass.tag}</span>
                  )}
                  <h3 className="text-xl font-bold pt-2">{pass.name}</h3>
                  <p className="text-slate-500 dark:text-slate-400 text-sm">{pass.description}</p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-primary">₹{pass.price}</div>
                  <div className="text-xs text-slate-400 font-medium">Monthly</div>
                </div>
              </div>
              <div className="space-y-3 mb-6">
                {pass.benefits.map((benefit, i) => (
                  <div key={i} className="flex items-center gap-3 text-sm text-slate-600 dark:text-slate-300">
                    <CheckCircle className="text-primary size-5" />
                    <span>{benefit}</span>
                  </div>
                ))}
              </div>
              <button 
                onClick={onSelect}
                className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-3.5 rounded-xl transition-all active:scale-[0.98]"
              >
                Buy Now
              </button>
            </div>
          </div>
        ))}
      </main>

      <nav className="fixed bottom-0 left-0 right-0 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 px-6 py-3 pb-8 flex justify-between items-center z-50">
        <button onClick={onBack} className="flex flex-col items-center gap-1 text-slate-400">
          <Home className="size-6" />
          <span className="text-[10px] font-bold">Home</span>
        </button>
        <button className="flex flex-col items-center gap-1 text-primary">
          <Ticket className="size-6" style={{ fontVariationSettings: "'FILL' 1" }} />
          <span className="text-[10px] font-bold">Passes</span>
        </button>
        <button className="flex flex-col items-center gap-1 text-slate-400">
          <Route className="size-6" />
          <span className="text-[10px] font-bold">Routes</span>
        </button>
        <button className="flex flex-col items-center gap-1 text-slate-400">
          <User className="size-6" />
          <span className="text-[10px] font-bold">Profile</span>
        </button>
      </nav>
    </div>
  );
}
