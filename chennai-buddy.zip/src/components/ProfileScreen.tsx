import { ArrowLeft, Edit, Verified, CreditCard, History, HelpCircle, Settings, LogOut, Home, Ticket, Palette, User, Bus, MapPin } from 'lucide-react';
import { motion } from 'motion/react';
import { Screen } from '../types';

interface ProfileScreenProps {
  onNavigate: (screen: Screen) => void;
}

export default function ProfileScreen({ onNavigate }: ProfileScreenProps) {
  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-background-dark">
      {/* Top Header */}
      <div className="flex items-center px-4 pb-2 pt-6 justify-between bg-background-light dark:bg-background-dark sticky top-0 z-10">
        <button 
          onClick={() => onNavigate('home')}
          className="flex size-12 shrink-0 items-center justify-center rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <ArrowLeft className="size-6" />
        </button>
        <h2 className="text-lg font-bold leading-tight tracking-tight flex-1 text-center">Profile</h2>
        <div className="flex w-12 items-center justify-end">
          <button className="flex size-10 items-center justify-center rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors">
            <Edit className="text-primary size-5" />
          </button>
        </div>
      </div>

      {/* Profile Info */}
      <div className="flex p-6 relative overflow-hidden">
        {/* Decorative elements */}
        <motion.div 
          animate={{ x: [0, 10, 0], y: [0, 5, 0] }}
          transition={{ duration: 5, repeat: Infinity }}
          className="absolute top-0 right-0 opacity-10"
        >
          <Bus className="size-24 text-primary" />
        </motion.div>

        <div className="flex w-full flex-col gap-4 items-center relative z-10">
          <motion.div 
            whileHover={{ scale: 1.05 }}
            className="relative"
          >
            <div 
              className="bg-center bg-no-repeat aspect-square bg-cover rounded-full min-h-32 w-32 border-4 border-white dark:border-slate-800 shadow-xl"
              style={{ backgroundImage: 'url("https://picsum.photos/seed/chennai-user/400/400")' }}
            ></div>
            <div className="absolute bottom-1 right-1 bg-emerald-500 text-white p-1.5 rounded-full border-4 border-white dark:border-slate-800 flex items-center justify-center shadow-lg">
              <Verified className="size-4" />
            </div>
          </motion.div>
          <div className="flex flex-col items-center justify-center">
            <h1 className="text-2xl font-black leading-tight tracking-tight text-center text-slate-900 dark:text-white">Arjun Kumar</h1>
            <div className="flex items-center gap-1.5 mt-1">
              <span className="text-primary text-[10px] font-black uppercase tracking-widest bg-primary/10 px-3 py-1 rounded-full">Verified Passenger</span>
            </div>
            <p className="text-slate-500 dark:text-slate-400 text-xs font-bold mt-2 flex items-center gap-1">
              <MapPin className="size-3" /> Chennai, Tamil Nadu
            </p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="px-6 flex gap-4 mb-6"
      >
        <div className="flex-1 bg-white dark:bg-slate-800 p-4 rounded-2xl shadow-sm flex flex-col items-center border border-slate-100 dark:border-slate-700">
          <span className="text-primary font-black text-xl">24</span>
          <span className="text-slate-500 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider">Trips</span>
        </div>
        <div className="flex-1 bg-white dark:bg-slate-800 p-4 rounded-2xl shadow-sm flex flex-col items-center border border-slate-100 dark:border-slate-700">
          <span className="text-primary font-black text-xl">₹1,240</span>
          <span className="text-slate-500 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider">Balance</span>
        </div>
      </motion.div>

      {/* Settings List */}
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="flex flex-col gap-1 px-4"
      >
        <h3 className="text-slate-500 dark:text-slate-400 text-xs font-bold uppercase tracking-widest px-2 pb-2 pt-4">Account Settings</h3>
        
        <button className="flex items-center gap-4 bg-white dark:bg-slate-800 px-4 py-4 rounded-xl shadow-sm hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors mb-2">
          <div className="flex items-center justify-center rounded-lg bg-primary/10 text-primary shrink-0 size-10">
            <CreditCard className="size-6" />
          </div>
          <div className="flex flex-col flex-1 text-left">
            <p className="text-base font-semibold leading-normal">Saved Cards</p>
            <p className="text-xs text-slate-500 dark:text-slate-400">Manage your payment methods</p>
          </div>
          <span className="material-symbols-outlined text-slate-400">chevron_right</span>
        </button>

        <button className="flex items-center gap-4 bg-white dark:bg-slate-800 px-4 py-4 rounded-xl shadow-sm hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors mb-2">
          <div className="flex items-center justify-center rounded-lg bg-primary/10 text-primary shrink-0 size-10">
            <History className="size-6" />
          </div>
          <div className="flex flex-col flex-1 text-left">
            <p className="text-base font-semibold leading-normal">Transaction History</p>
            <p className="text-xs text-slate-500 dark:text-slate-400">View your past tickets & passes</p>
          </div>
          <span className="material-symbols-outlined text-slate-400">chevron_right</span>
        </button>

        <h3 className="text-slate-500 dark:text-slate-400 text-xs font-bold uppercase tracking-widest px-2 pb-2 pt-4">Support & App</h3>
        
        <button className="flex items-center gap-4 bg-white dark:bg-slate-800 px-4 py-4 rounded-xl shadow-sm hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors mb-2">
          <div className="flex items-center justify-center rounded-lg bg-primary/10 text-primary shrink-0 size-10">
            <HelpCircle className="size-6" />
          </div>
          <div className="flex flex-col flex-1 text-left">
            <p className="text-base font-semibold leading-normal">Help & Support</p>
            <p className="text-xs text-slate-500 dark:text-slate-400">FAQs and customer care</p>
          </div>
          <span className="material-symbols-outlined text-slate-400">chevron_right</span>
        </button>

        <button 
          onClick={() => onNavigate('admin')}
          className="flex items-center gap-4 bg-white dark:bg-slate-800 px-4 py-4 rounded-xl shadow-sm hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors mb-2"
        >
          <div className="flex items-center justify-center rounded-lg bg-primary/10 text-primary shrink-0 size-10">
            <Settings className="size-6" />
          </div>
          <div className="flex flex-col flex-1 text-left">
            <p className="text-base font-semibold leading-normal">Admin Dashboard</p>
            <p className="text-xs text-slate-500 dark:text-slate-400">Manage system settings</p>
          </div>
          <span className="material-symbols-outlined text-slate-400">chevron_right</span>
        </button>

        <button 
          onClick={() => onNavigate('login')}
          className="flex items-center gap-4 bg-white dark:bg-slate-800 px-4 py-4 rounded-xl shadow-sm hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors mb-8 group"
        >
          <div className="flex items-center justify-center rounded-lg bg-red-100 dark:bg-red-900/30 text-red-600 shrink-0 size-10">
            <LogOut className="size-6" />
          </div>
          <div className="flex flex-col flex-1 text-left">
            <p className="text-base font-semibold leading-normal text-red-600">Logout</p>
          </div>
        </button>
      </motion.div>

      {/* Bottom Nav */}
      <div className="mt-auto border-t border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md px-4 pb-6 pt-2 flex justify-around items-center">
        <button onClick={() => onNavigate('home')} className="flex flex-col items-center gap-1 text-slate-400 hover:text-primary transition-colors">
          <Home className="size-6" />
          <p className="text-[10px] font-medium leading-none">Home</p>
        </button>
        <button onClick={() => onNavigate('tickets')} className="flex flex-col items-center gap-1 text-slate-400 hover:text-primary transition-colors">
          <Ticket className="size-6" />
          <p className="text-[10px] font-medium leading-none">Tickets</p>
        </button>
        <button onClick={() => onNavigate('pass_selection')} className="flex flex-col items-center gap-1 text-slate-400 hover:text-primary transition-colors">
          <Palette className="size-6" />
          <p className="text-[10px] font-medium leading-none">Passes</p>
        </button>
        <button onClick={() => onNavigate('profile')} className="flex flex-col items-center gap-1 text-primary">
          <User className="size-6" style={{ fontVariationSettings: "'FILL' 1" }} />
          <p className="text-[10px] font-medium leading-none">Profile</p>
        </button>
      </div>
    </div>
  );
}
