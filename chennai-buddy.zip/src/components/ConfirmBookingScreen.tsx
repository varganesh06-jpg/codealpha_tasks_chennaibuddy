import { ArrowLeft, Ticket, Clock, MapPin, Info, Wallet, ArrowRight } from 'lucide-react';

interface ConfirmBookingScreenProps {
  onBack: () => void;
  onConfirm: () => void;
}

export default function ConfirmBookingScreen({ onBack, onConfirm }: ConfirmBookingScreenProps) {
  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-background-dark">
      {/* Header */}
      <div className="sticky top-0 z-10 flex items-center bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md p-4 pb-2 justify-between">
        <button 
          onClick={onBack}
          className="text-primary flex size-12 shrink-0 items-center justify-start cursor-pointer hover:bg-primary/5 rounded-full"
        >
          <ArrowLeft className="size-6" />
        </button>
        <h2 className="text-slate-900 dark:text-slate-100 text-lg font-bold leading-tight tracking-tight flex-1 text-center pr-12">Confirm Booking</h2>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto pb-32">
        {/* Trip Summary Card */}
        <div className="p-4">
          <div className="flex flex-col items-stretch justify-start rounded-xl overflow-hidden shadow-sm bg-white dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
            <div 
              className="w-full bg-center bg-no-repeat aspect-[16/9] bg-cover" 
              style={{ backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuA5CebhYxARfegJ0n3beg81dhZozEl68gmEG9fiaNQ4X2mifGaKv5FaLevpXp3Wb3bDC-c9Dgr0lv6GosqQIiroBRn8BkUIY15_OASwejr32WW-CQugpHCuSW7kY0ovUWnQ2MZRA5mX1DhzlpqB69kNgZ-Zw7YURIhxAE-rarRCghU4P5QLtlR_tv8c2v9HGcQSZsTWI-tdvb9tMgC1U7FcXoQmgxDzg8Q-lvSWdFnKOSzWq2UOLMsyyHntZGZMUy_HbXfPKxZqFj_b")' }}
            ></div>
            <div className="flex w-full flex-col gap-1 p-4">
              <div className="flex justify-between items-start">
                <span className="px-2 py-1 bg-primary/10 text-primary text-[10px] font-bold uppercase rounded tracking-wider">MTC Deluxe</span>
                <span className="text-slate-400 text-xs font-medium">Route 570</span>
              </div>
              <p className="text-slate-900 dark:text-slate-100 text-xl font-bold mt-1">Chennai Central - OMR</p>
              <div className="flex items-center gap-2 mt-2">
                <Ticket className="text-primary size-4" />
                <p className="text-slate-500 dark:text-slate-400 text-sm">Digital Ticket Buddy</p>
              </div>
            </div>
          </div>
        </div>

        {/* Journey Details */}
        <div className="px-4 py-2">
          <h3 className="text-slate-900 dark:text-slate-100 text-sm font-bold uppercase tracking-wider mb-3">Journey Details</h3>
          <div className="space-y-1 bg-white dark:bg-slate-800/50 rounded-xl p-2 border border-slate-200 dark:border-slate-700">
            <div className="flex items-center gap-4 px-3 py-3 border-b border-slate-100 dark:border-slate-700/50">
              <div className="text-primary flex items-center justify-center rounded-lg bg-primary/10 shrink-0 size-10">
                <Clock className="size-6" />
              </div>
              <div className="flex flex-col">
                <p className="text-slate-900 dark:text-slate-100 text-sm font-semibold">Departure: 09:30 AM</p>
                <p className="text-slate-500 dark:text-slate-400 text-xs">Chennai Central Railway Station</p>
              </div>
            </div>
            <div className="flex items-center gap-4 px-3 py-3">
              <div className="text-primary flex items-center justify-center rounded-lg bg-primary/10 shrink-0 size-10">
                <MapPin className="size-6" />
              </div>
              <div className="flex flex-col">
                <p className="text-slate-900 dark:text-slate-100 text-sm font-semibold">Arrival: 10:45 AM</p>
                <p className="text-slate-500 dark:text-slate-400 text-xs">SIPCOT IT Park, OMR</p>
              </div>
            </div>
          </div>
        </div>

        {/* Fare Breakdown */}
        <div className="px-4 py-6">
          <h3 className="text-slate-900 dark:text-slate-100 text-sm font-bold uppercase tracking-wider mb-3">Fare Breakdown</h3>
          <div className="bg-white dark:bg-slate-800/50 rounded-xl p-4 space-y-3 border border-slate-200 dark:border-slate-700">
            <div className="flex justify-between items-center text-sm">
              <span className="text-slate-500 dark:text-slate-400">Base Fare (Deluxe)</span>
              <span className="font-medium">₹45.00</span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span className="text-slate-500 dark:text-slate-400 flex items-center gap-1">
                Cloud Service Fee 
                <Info className="size-3" />
              </span>
              <span className="font-medium">₹2.50</span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span className="text-slate-500 dark:text-slate-400">Taxes (GST)</span>
              <span className="font-medium">₹1.50</span>
            </div>
            <div className="pt-3 border-t border-dashed border-slate-200 dark:border-slate-700 flex justify-between items-center">
              <span className="text-slate-900 dark:text-slate-100 font-bold">Total Amount</span>
              <span className="text-primary text-xl font-extrabold">₹49.00</span>
            </div>
          </div>
        </div>

        {/* Payment Method */}
        <div className="px-4">
          <div className="flex items-center justify-between p-4 bg-primary/5 rounded-xl border border-primary/10">
            <div className="flex items-center gap-3">
              <Wallet className="text-primary size-6" />
              <div className="flex flex-col">
                <span className="text-xs text-slate-500">Payment Method</span>
                <span className="text-sm font-bold">Chennai Buddy Wallet</span>
              </div>
            </div>
            <button className="text-primary text-xs font-bold">CHANGE</button>
          </div>
        </div>
      </div>

      {/* Bottom Action */}
      <div className="absolute bottom-0 left-0 right-0 p-4 bg-background-light/90 dark:bg-background-dark/90 backdrop-blur-xl border-t border-slate-200 dark:border-slate-800">
        <button 
          onClick={onConfirm}
          className="w-full bg-primary hover:bg-primary/90 text-white py-4 rounded-xl font-bold text-lg shadow-lg shadow-primary/30 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
        >
          <span>Confirm & Pay ₹49.00</span>
          <ArrowRight className="size-5" />
        </button>
        <p className="text-center text-[10px] text-slate-400 mt-3 px-8">
          By clicking confirm, you agree to MTC's Terms of Service and Privacy Policy.
        </p>
      </div>
    </div>
  );
}
