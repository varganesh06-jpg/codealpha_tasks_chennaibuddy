import { ArrowLeft, Route, Camera, Wallet, Home, Ticket, Map as MapIcon, User } from 'lucide-react';

interface PassDetailsScreenProps {
  onBack: () => void;
  onActivate: () => void;
}

export default function PassDetailsScreen({ onBack, onActivate }: PassDetailsScreenProps) {
  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-background-dark pb-32">
      <header className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-4 flex items-center gap-3">
        <button 
          onClick={onBack}
          className="flex items-center justify-center size-10 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
        >
          <ArrowLeft className="size-6" />
        </button>
        <h1 className="text-xl font-bold">Pass Details</h1>
      </header>

      <main className="max-w-md mx-auto px-4 py-2 space-y-6">
        {/* Progress */}
        <div className="flex items-center justify-between px-2">
          <div className="flex items-center gap-2">
            <div className="size-8 rounded-full bg-primary text-white flex items-center justify-center font-bold text-sm">1</div>
            <span className="text-sm font-semibold">Customization</span>
          </div>
          <div className="h-[1px] flex-1 bg-slate-300 dark:bg-slate-700 mx-4"></div>
          <div className="flex items-center gap-2 opacity-40">
            <div className="size-8 rounded-full bg-slate-300 dark:bg-slate-700 text-slate-600 dark:text-slate-400 flex items-center justify-center font-bold text-sm">2</div>
            <span className="text-sm font-semibold">Payment</span>
          </div>
        </div>

        {/* Route Selection */}
        <section className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-100 dark:border-slate-800">
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-500 mb-4">Route Selection</h2>
          <div className="space-y-4">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold px-1 text-slate-600 dark:text-slate-400">Primary Route</label>
              <div className="relative">
                <Route className="absolute left-4 top-1/2 -translate-y-1/2 text-primary size-5" />
                <select className="w-full rounded-xl border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 h-14 pl-12 pr-4 focus:ring-2 focus:ring-primary focus:border-transparent appearance-none outline-none">
                  <option>Route 21G: Tambaram to Broadway</option>
                  <option>Route 570: Kelambakkam to CMBT</option>
                  <option>Route 102: Kelambakkam to Broadway</option>
                  <option>Route 19B: T.Nagar to Kelambakkam</option>
                </select>
              </div>
            </div>
          </div>
        </section>

        {/* ID Verification */}
        <section className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-100 dark:border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-500">Identity Verification</h2>
            <span className="text-[10px] font-bold bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 px-2 py-0.5 rounded-full uppercase">Required</span>
          </div>
          <div className="flex flex-col items-center justify-center border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-xl p-8 bg-slate-50 dark:bg-slate-950/50">
            <div className="size-16 rounded-full bg-primary/10 text-primary flex items-center justify-center mb-4">
              <Camera className="size-8" />
            </div>
            <p className="text-sm font-bold text-slate-900 dark:text-white">Upload Digital ID Photo</p>
            <p className="text-xs text-slate-500 mt-1 text-center">Clear passport-size photo for pass generation</p>
            <button className="mt-4 px-6 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-full text-xs font-bold shadow-sm">Choose File</button>
          </div>
        </section>

        {/* Validity */}
        <section className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-100 dark:border-slate-800">
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-500 mb-4">Validity Period</h2>
          <div className="grid grid-cols-3 gap-3">
            <button className="flex flex-col items-center justify-center p-3 rounded-xl border-2 border-primary bg-primary/5">
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400">MAY</span>
              <span className="text-lg font-bold text-primary">2024</span>
            </button>
            <button className="flex flex-col items-center justify-center p-3 rounded-xl border-2 border-slate-100 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-600 transition-all">
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400">JUN</span>
              <span className="text-lg font-bold">2024</span>
            </button>
            <button className="flex flex-col items-center justify-center p-3 rounded-xl border-2 border-slate-100 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-600 transition-all">
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400">JUL</span>
              <span className="text-lg font-bold">2024</span>
            </button>
          </div>
        </section>

        {/* Price Summary */}
        <section className="bg-slate-900 text-white rounded-2xl p-6 shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-10">
            <Ticket className="size-32" />
          </div>
          <div className="relative z-10">
            <h2 className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-4">Price Summary</h2>
            <div className="space-y-2">
              <div className="flex justify-between items-center text-sm">
                <span className="text-slate-400">Monthly Pass (Standard)</span>
                <span className="font-semibold">₹1,000.00</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-slate-400">Service Fee</span>
                <span className="font-semibold">₹20.00</span>
              </div>
              <div className="h-[1px] bg-slate-700 my-4"></div>
              <div className="flex justify-between items-end">
                <div>
                  <span className="text-xs text-slate-400 block uppercase">Grand Total</span>
                  <span className="text-3xl font-bold">₹1,020.00</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] bg-green-500/20 text-green-400 px-2 py-1 rounded-full font-bold">DIGITAL READY</span>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Bottom Action */}
      <div className="fixed bottom-0 left-0 right-0 z-50">
        <div className="max-w-md mx-auto px-4 pb-4">
          <button 
            onClick={onActivate}
            className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-4 rounded-2xl shadow-[0_8px_30px_rgb(19,91,236,0.3)] transition-all flex items-center justify-center gap-3 active:scale-[0.98]"
          >
            <Wallet className="size-6" />
            <span>Pay & Activate Pass</span>
          </button>
        </div>
        <nav className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 px-6 py-3 flex justify-between items-center pb-8">
          <button onClick={onBack} className="flex flex-col items-center gap-1 text-slate-400">
            <Home className="size-6" />
            <span className="text-[10px] font-bold">Home</span>
          </button>
          <button className="flex flex-col items-center gap-1 text-primary">
            <Ticket className="size-6" style={{ fontVariationSettings: "'FILL' 1" }} />
            <span className="text-[10px] font-bold">Passes</span>
          </button>
          <button className="flex flex-col items-center gap-1 text-slate-400">
            <MapIcon className="size-6" />
            <span className="text-[10px] font-bold">Map</span>
          </button>
          <button className="flex flex-col items-center gap-1 text-slate-400">
            <User className="size-6" />
            <span className="text-[10px] font-bold">Profile</span>
          </button>
        </nav>
      </div>
    </div>
  );
}
