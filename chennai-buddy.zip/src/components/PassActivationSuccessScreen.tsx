import { X, Check, Wifi, Calendar, Banknote, Wallet, Home, User } from 'lucide-react';
import { Screen } from '../types';

interface PassActivationSuccessScreenProps {
  onDone: () => void;
  onNavigate: (screen: Screen) => void;
}

export default function PassActivationSuccessScreen({ onDone, onNavigate }: PassActivationSuccessScreenProps) {
  return (
    <div className="relative flex h-screen w-full flex-col bg-background-light dark:bg-background-dark overflow-hidden">
      {/* Header */}
      <div className="flex items-center p-6 justify-between">
        <div className="flex items-center gap-3">
          <div className="text-primary flex size-10 shrink-0 items-center justify-center bg-primary/10 rounded-lg">
            <span className="material-symbols-outlined text-2xl">directions_bus</span>
          </div>
          <div>
            <h2 className="text-slate-900 dark:text-slate-100 text-lg font-bold leading-none">Chennai Buddy</h2>
          </div>
        </div>
        <button onClick={onDone} className="p-2 text-slate-400">
          <X className="size-6" />
        </button>
      </div>

      {/* Success Animation Area */}
      <div className="flex flex-col items-center px-6 pt-4 pb-6 text-center relative">
        <div className="absolute top-10 left-1/4 w-2 h-2 rounded-full bg-yellow-400"></div>
        <div className="absolute top-20 right-1/4 w-3 h-3 rounded-full bg-blue-400"></div>
        <div className="absolute top-5 right-1/3 w-2 h-2 rounded-full bg-pink-400"></div>
        <div className="size-20 bg-emerald-500/10 rounded-full flex items-center justify-center mb-4">
          <div className="size-14 bg-emerald-500 rounded-full flex items-center justify-center shadow-lg shadow-emerald-500/30">
            <Check className="text-white size-8 font-bold" />
          </div>
        </div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Pass Activated!</h1>
        <p className="text-slate-500 dark:text-slate-400 mt-1">Your monthly commuter pass is now active and ready for use.</p>
      </div>

      {/* Pass Card */}
      <div className="px-6 py-2">
        <div className="bg-gradient-to-br from-primary to-[#0a2e7a] rounded-3xl p-6 text-white shadow-2xl shadow-primary/30 relative overflow-hidden aspect-[1.6/1]">
          <div className="absolute top-0 right-0 p-8 opacity-10">
            <span className="material-symbols-outlined text-[120px] -rotate-12">directions_bus</span>
          </div>
          <div className="relative z-10 h-full flex flex-col justify-between">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs font-medium opacity-80 uppercase tracking-widest">Monthly Travel Pass</p>
                <h3 className="text-xl font-bold">Chennai Transit</h3>
              </div>
              <div className="bg-white/20 backdrop-blur-md rounded-lg p-2">
                <Wifi className="text-white size-6" />
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-end">
                <div>
                  <p className="text-[10px] opacity-70 uppercase mb-1">Pass Number</p>
                  <p className="font-mono text-lg font-semibold tracking-wider">CH-8829-0012</p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] opacity-70 uppercase mb-1">Status</p>
                  <span className="bg-emerald-500 text-[10px] font-bold px-2 py-1 rounded-full uppercase">Active</span>
                </div>
              </div>
              <div className="pt-2 border-t border-white/20 flex justify-between">
                <div>
                  <p className="text-[10px] opacity-70 uppercase">Valid From</p>
                  <p className="text-xs font-bold">01 Oct 2023</p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] opacity-70 uppercase">Valid Until</p>
                  <p className="text-xs font-bold">31 Oct 2023</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Details */}
      <div className="px-6 py-8 space-y-4">
        <div className="flex items-center justify-between p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <Calendar className="text-slate-400 size-5" />
            <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Validity Period</span>
          </div>
          <span className="text-sm font-bold text-slate-900 dark:text-white">30 Days</span>
        </div>
        <div className="flex items-center justify-between p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <Banknote className="text-slate-400 size-5" />
            <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Transaction ID</span>
          </div>
          <span className="text-sm font-bold text-slate-900 dark:text-white">#TXN-992011</span>
        </div>
      </div>

      {/* Actions */}
      <div className="mt-auto px-6 pb-24">
        <button 
          onClick={() => onNavigate('tickets')}
          className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-4 rounded-2xl shadow-xl shadow-primary/20 transition-all flex items-center justify-center gap-2 active:scale-[0.98]"
        >
          <Wallet className="size-6" />
          <span>View in Wallet</span>
        </button>
        <button 
          onClick={onDone}
          className="w-full mt-4 text-slate-500 dark:text-slate-400 font-semibold py-2"
        >
          Back to Home
        </button>
      </div>

      {/* Bottom Nav */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl border-t border-slate-200 dark:border-slate-800 px-6 pb-8 pt-3 flex justify-between items-center z-50">
        <button onClick={() => onNavigate('home')} className="flex flex-col items-center gap-1 text-slate-400">
          <Home className="size-6" />
          <span className="text-[10px] font-medium">Home</span>
        </button>
        <button onClick={() => onNavigate('tickets')} className="flex flex-col items-center gap-1 text-primary">
          <Wallet className="size-6" style={{ fontVariationSettings: "'FILL' 1" }} />
          <span className="text-[10px] font-bold">Wallet</span>
        </button>
        <button onClick={() => onNavigate('home')} className="flex flex-col items-center gap-1 text-slate-400">
          <div className="relative">
            <span className="material-symbols-outlined">directions_bus</span>
            <div className="absolute -top-1 -right-1 size-2 bg-red-500 rounded-full border-2 border-white dark:border-slate-900"></div>
          </div>
          <span className="text-[10px] font-medium">Routes</span>
        </button>
        <button onClick={() => onNavigate('profile')} className="flex flex-col items-center gap-1 text-slate-400">
          <User className="size-6" />
          <span className="text-[10px] font-medium">Profile</span>
        </button>
      </div>
    </div>
  );
}
