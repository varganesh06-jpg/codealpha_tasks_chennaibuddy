import React from 'react';

export const Logo = ({ className = "size-10" }: { className?: string }) => (
  <div className={`relative flex items-center justify-center bg-primary rounded-xl overflow-hidden shadow-lg ${className}`}>
    <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent"></div>
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="size-6 text-white relative z-10">
      <path d="M4 18V8.5C4 6.567 5.567 5 7.5 5H16.5C18.433 5 20 6.567 20 8.5V18M4 18H20M4 18V19C4 19.5523 4.44772 20 5 20H6C6.55228 20 7 19.5523 7 19V18M20 18V19C20 19.5523 19.5523 20 19 20H18C17.4477 20 17 19.5523 17 19V18M6 9H8M16 9H18M6 13H18M9 17H15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <circle cx="8" cy="17" r="1" fill="currentColor"/>
      <circle cx="16" cy="17" r="1" fill="currentColor"/>
      {/* Cute face */}
      <circle cx="10" cy="11" r="0.5" fill="currentColor"/>
      <circle cx="14" cy="11" r="0.5" fill="currentColor"/>
      <path d="M11 13C11 13 11.5 13.5 12 13.5C12.5 13.5 13 13 13 13" stroke="currentColor" strokeWidth="0.5" strokeLinecap="round"/>
      {/* Blush */}
      <circle cx="9" cy="12" r="0.5" fill="#ff9999" opacity="0.6"/>
      <circle cx="15" cy="12" r="0.5" fill="#ff9999" opacity="0.6"/>
    </svg>
  </div>
);
