import { ArrowLeft, SlidersHorizontal, MapPin, Navigation, Route, Armchair, ArrowRight, Ticket, UserCircle, Home } from 'lucide-react';
import { SAMPLE_ROUTES } from '../constants';
import { Screen } from '../types';

interface SearchResultsScreenProps {
  onBack: () => void;
  onBook: () => void;
}

export default function SearchResultsScreen({ onBack, onBook }: SearchResultsScreenProps) {
  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-background-dark">
      {/* Header */}
      <header className="sticky top-0 z-20 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md">
        <div className="flex items-center px-4 py-3 justify-between">
          <div className="flex items-center gap-3">
            <button 
              onClick={onBack}
              className="flex items-center justify-center size-10 rounded-full hover:bg-primary/10 text-slate-900 dark:text-slate-100"
            >
              <ArrowLeft className="size-6" />
            </button>
            <div>
              <h1 className="text-lg font-bold leading-tight">CMBT to Siruseri</h1>
              <p className="text-xs text-slate-500 dark:text-slate-400">Today, 24 Oct • 2 Adults</p>
            </div>
          </div>
          <button className="flex size-10 items-center justify-center rounded-full hover:bg-primary/10">
            <SlidersHorizontal className="size-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="px-4">
          <div className="flex border-b border-slate-200 dark:border-slate-800">
            <button className="flex-1 py-3 text-sm font-bold border-b-2 border-primary text-primary">All Buses</button>
            <button className="flex-1 py-3 text-sm font-medium text-slate-500 dark:text-slate-400">AC / Deluxe</button>
            <button className="flex-1 py-3 text-sm font-medium text-slate-500 dark:text-slate-400">Express</button>
          </div>
        </div>

        {/* Quick Filters */}
        <div className="flex gap-2 p-3 overflow-x-auto no-scrollbar">
          {['Departure', 'Price', 'Seats'].map((filter) => (
            <button key={filter} className="flex h-9 shrink-0 items-center justify-center gap-x-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-4 shadow-sm">
              <span className="text-xs font-semibold">{filter}</span>
              <span className="material-symbols-outlined text-sm">expand_more</span>
            </button>
          ))}
        </div>
      </header>

      {/* Bus List */}
      <main className="flex-1 px-4 py-2 space-y-4 pb-24">
        {SAMPLE_ROUTES.map((route) => (
          <div key={route.id} className="bg-white dark:bg-slate-900 rounded-xl p-4 shadow-sm border border-slate-100 dark:border-slate-800 relative overflow-hidden">
            {route.type === 'Volvo AC' && (
              <div className="absolute top-0 right-0 bg-blue-500 text-white text-[10px] px-3 py-1 rounded-bl-lg font-bold uppercase tracking-widest">AC</div>
            )}
            <div className="flex justify-between items-start mb-3">
              <div className="flex items-center gap-2">
                <span className="bg-primary/10 text-primary px-2 py-1 rounded text-sm font-bold tracking-wider">{route.number}</span>
                <span className="text-xs font-medium text-slate-400 dark:text-slate-500">MTC {route.type}</span>
              </div>
              <div className="text-right">
                <p className="text-primary text-lg font-bold">₹{route.price.toFixed(2)}</p>
              </div>
            </div>

            <div className="space-y-3 mb-4">
              <div className="flex items-center gap-3">
                <div className="flex flex-col items-center gap-1">
                  <div className="size-2 rounded-full bg-primary"></div>
                  <div className="w-0.5 h-6 bg-slate-200 dark:bg-slate-700"></div>
                  <div className="size-2 rounded-full border-2 border-primary"></div>
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-center">
                    <p className="text-sm font-bold">{route.departure}</p>
                    <p className="text-[10px] text-slate-400">{route.duration}</p>
                    <p className="text-sm font-bold">{route.arrival}</p>
                  </div>
                  <div className="flex justify-between items-center text-xs text-slate-500 mt-1">
                    <span>{route.from}</span>
                    <ArrowRight className="size-4" />
                    <span>{route.to}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2 bg-background-light dark:bg-background-dark/50 p-2 rounded-lg">
                <Route className="text-slate-400 size-4" />
                <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate">{route.stops.join(' • ')}</p>
              </div>
            </div>

            <div className="flex justify-between items-center pt-3 border-t border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-1">
                <Armchair className={`size-4 ${route.seatsLeft < 5 ? 'text-amber-500' : 'text-green-500'}`} />
                <p className={`text-xs font-medium ${route.seatsLeft < 5 ? 'text-amber-600' : 'text-green-600'}`}>
                  {route.seatsLeft} Seats left
                </p>
              </div>
              <button 
                onClick={onBook}
                className="bg-primary hover:bg-primary/90 text-white px-6 py-2 rounded-lg text-sm font-bold shadow-md shadow-primary/20 transition-all active:scale-95"
              >
                Book
              </button>
            </div>
          </div>
        ))}

        <div className="py-10 text-center">
          <p className="text-slate-400 text-sm">Showing 15 more results</p>
        </div>
      </main>

      {/* Bottom Nav */}
      <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md z-30">
        <div className="flex gap-2 border-t border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90 backdrop-blur-lg px-4 pb-8 pt-3 shadow-lg">
          <button className="flex flex-1 flex-col items-center justify-center gap-1 text-primary">
            <span className="material-symbols-outlined" style={{ fontVariationSettings: "'FILL' 1" }}>directions_bus</span>
            <p className="text-[10px] font-bold uppercase tracking-wider">Search</p>
          </button>
          <button className="flex flex-1 flex-col items-center gap-1 text-slate-400">
            <Ticket className="size-6" />
            <p className="text-[10px] font-medium uppercase tracking-wider">Tickets</p>
          </button>
          <button className="flex flex-1 flex-col items-center gap-1 text-slate-400">
            <span className="material-symbols-outlined">contact_emergency</span>
            <p className="text-[10px] font-medium uppercase tracking-wider">Passes</p>
          </button>
          <button className="flex flex-1 flex-col items-center gap-1 text-slate-400">
            <UserCircle className="size-6" />
            <p className="text-[10px] font-medium uppercase tracking-wider">Profile</p>
          </button>
        </div>
      </nav>
    </div>
  );
}
