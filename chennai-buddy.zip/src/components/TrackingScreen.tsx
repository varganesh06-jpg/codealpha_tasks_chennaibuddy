import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, Info, Plus, Minus, Locate, Navigation, RefreshCw, Home, Ticket, User, MapPin, Gauge, Users, Clock, ShieldCheck, Bus as BusIcon } from 'lucide-react';
import { Screen } from '../types';
import { Logo } from './Logo';

interface TrackingScreenProps {
  onBack: () => void;
  onNavigate: (screen: Screen) => void;
}

export default function TrackingScreen({ onBack, onNavigate }: TrackingScreenProps) {
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [busOffset, setBusOffset] = useState({ x: 0, y: 0 });
  const [busData, setBusData] = useState({
    speed: 42,
    occupancy: 65,
    temp: 24,
    driver: "K. Muthu",
    rating: 4.8,
    busModel: "Ashok Leyland Viking",
    fuelType: "Electric",
    lastService: "12 Feb 2026"
  });

  useEffect(() => {
    if ("geolocation" in navigator) {
      const watchId = navigator.geolocation.watchPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        (error) => {
          console.error("Error getting location", error);
        },
        { enableHighAccuracy: true }
      );

      return () => navigator.geolocation.clearWatch(watchId);
    }
  }, []);

  // Simulate bus movement and data updates
  useEffect(() => {
    const interval = setInterval(() => {
      setBusOffset(prev => ({
        x: prev.x + (Math.random() - 0.5) * 8,
        y: prev.y + (Math.random() - 0.5) * 8,
      }));
      setBusData(prev => ({
        ...prev,
        speed: Math.floor(35 + Math.random() * 15),
        occupancy: Math.min(100, Math.max(0, prev.occupancy + Math.floor((Math.random() - 0.5) * 4)))
      }));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative flex h-screen w-full flex-col bg-background-light dark:bg-background-dark overflow-hidden">
      {/* Header */}
      <motion.header 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="flex items-center bg-white/80 dark:bg-background-dark/80 backdrop-blur-md p-4 sticky top-0 z-20 border-b border-slate-200 dark:border-slate-800"
      >
        <button 
          onClick={onBack}
          className="flex size-10 items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <ArrowLeft className="size-6" />
        </button>
        <div className="flex-1 text-center">
          <h1 className="text-lg font-bold leading-tight tracking-tight">Chennai Buddy</h1>
          <div className="flex items-center justify-center gap-2">
            <span className="size-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
            <p className="text-[10px] uppercase tracking-widest text-primary font-bold">Live Tracking • Bus 29C</p>
          </div>
        </div>
        <button className="flex size-10 items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
          <Info className="size-5" />
        </button>
      </motion.header>

      {/* Map Area */}
      <main className="relative flex-1 overflow-hidden">
        <motion.div 
          initial={{ scale: 1.1, opacity: 0 }}
          animate={{ scale: 1.2, opacity: 1 }}
          className="absolute inset-0 z-0 bg-slate-200 dark:bg-slate-900 transition-all duration-1000" 
          style={{ 
            backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuDm3nfpWPHj8gBrhupktu9QLdlFyrGYHmRw1rasGnvKflveg6FXnU4gb8CYiTfc6dsGVA9Ld1zXU1XCv9g_x8QIJbBVCqSaVd2VoaexwsEVDlkuZDtJI6fM5jJM1OSOFL_OkH__ceKnGUlMetlVw8gGwpcBcsb4fwC7Fs4J7br6NUxAiTeKcd6qNqY8AG4mClEC4gK_mdF9iks2Yc2E0XYopjkr8SUij2y4xTM_c6o6xFUI_ONncfxLs7Mzz-5VSr30uBmogZZEMlA-')",
            backgroundSize: 'cover',
            backgroundPosition: userLocation ? `${50 + (userLocation.lng % 0.01) * 1000}% ${50 + (userLocation.lat % 0.01) * 1000}%` : 'center',
          }}
        >
          {/* User Marker */}
          {userLocation && (
            <motion.div 
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="absolute transition-all duration-1000"
              style={{ top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }}
            >
              <div className="relative flex items-center justify-center">
                <div className="absolute size-8 bg-blue-500/20 rounded-full animate-ping"></div>
                <div className="size-4 bg-blue-500 border-2 border-white rounded-full shadow-lg"></div>
              </div>
            </motion.div>
          )}

          {/* Bus Marker */}
          <motion.div 
            layout
            className="absolute transition-all duration-3000"
            style={{ 
              top: `calc(40% + ${busOffset.y}px)`, 
              left: `calc(60% + ${busOffset.x}px)`,
              transform: 'translate(-50%, -50%)' 
            }}
          >
            <div className="relative flex flex-col items-center gap-1">
              <div className="absolute size-12 bg-primary/20 rounded-full animate-pulse"></div>
              <motion.div 
                whileHover={{ scale: 1.2 }}
                className="relative z-10"
              >
                <Logo className="size-10 shadow-2xl border-2 border-white" />
              </motion.div>
              <div className="bg-primary text-white px-2 py-0.5 rounded-full text-[8px] font-bold shadow-lg">
                29C
              </div>
            </div>
          </motion.div>

          {/* Map Controls */}
          <div className="absolute top-4 right-4 flex flex-col gap-2">
            <button className="flex size-11 items-center justify-center rounded-xl bg-white dark:bg-slate-800 shadow-lg text-slate-900 dark:text-slate-100">
              <Plus className="size-5" />
            </button>
            <button className="flex size-11 items-center justify-center rounded-xl bg-white dark:bg-slate-800 shadow-lg text-slate-900 dark:text-slate-100">
              <Minus className="size-5" />
            </button>
            <button className="mt-4 flex size-11 items-center justify-center rounded-xl bg-primary shadow-lg text-white">
              <Locate className="size-5" />
            </button>
          </div>

          {/* Traffic Info */}
          <div className="absolute top-4 left-4">
            <div className="bg-white/90 dark:bg-slate-800/90 backdrop-blur-md p-3 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 max-w-[200px]">
              <div className="flex items-center gap-2 mb-2">
                <span className="size-2 bg-green-500 rounded-full"></span>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Live Traffic</span>
              </div>
              <p className="text-xs font-medium">Moderate traffic on Anna Salai Road</p>
            </div>
          </div>
        </motion.div>

        {/* Bottom Info Card */}
        <motion.div 
          initial={{ y: 100 }}
          animate={{ y: 0 }}
          className="absolute bottom-4 left-4 right-4 z-10 flex flex-col gap-3"
        >
          {/* Bus Stats Bar */}
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
            <div className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-md px-4 py-2 rounded-full shadow-lg border border-slate-200 dark:border-slate-800 flex items-center gap-2 shrink-0">
              <Gauge className="size-3 text-primary" />
              <span className="text-[10px] font-bold">{busData.speed} km/h</span>
            </div>
            <div className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-md px-4 py-2 rounded-full shadow-lg border border-slate-200 dark:border-slate-800 flex items-center gap-2 shrink-0">
              <Users className="size-3 text-primary" />
              <span className="text-[10px] font-bold">{busData.occupancy}% Full</span>
            </div>
            <div className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-md px-4 py-2 rounded-full shadow-lg border border-slate-200 dark:border-slate-800 flex items-center gap-2 shrink-0">
              <ShieldCheck className="size-3 text-emerald-500" />
              <span className="text-[10px] font-bold">Safe Drive</span>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
            <div className="p-4 flex items-center justify-between border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-3">
                <div className="size-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Navigation className="text-primary size-5" />
                </div>
                <div>
                  <p className="text-[10px] font-semibold text-slate-500 uppercase tracking-tighter">Next Stop</p>
                  <h3 className="text-base font-bold">Teynampet</h3>
                </div>
              </div>
              <div className="text-right">
                <motion.p 
                  key={busData.speed}
                  initial={{ scale: 1.2 }}
                  animate={{ scale: 1 }}
                  className="text-2xl font-black text-primary"
                >
                  4 <span className="text-xs font-bold uppercase">mins</span>
                </motion.p>
                <p className="text-[10px] text-slate-400">0.8 km away</p>
              </div>
            </div>
            
            <div className="p-4 grid grid-cols-2 gap-4">
              <div className="flex items-center gap-3">
                <div className="size-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
                  <User className="size-5 text-slate-500" />
                </div>
                <div>
                  <p className="text-[10px] text-slate-500 font-medium">Driver</p>
                  <p className="text-xs font-bold">{busData.driver}</p>
                  <div className="flex items-center gap-1">
                    <span className="text-[10px] text-amber-500">★</span>
                    <span className="text-[10px] font-bold">{busData.rating}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-end gap-3">
                <div className="text-right">
                  <p className="text-[10px] text-slate-500 font-medium">ETA Broadway</p>
                  <p className="text-xs font-bold">09:45 AM</p>
                </div>
                <button className="flex size-10 items-center justify-center bg-primary/10 text-primary rounded-full transition-all active:scale-95">
                  <RefreshCw className="size-5" />
                </button>
              </div>
            </div>

            {/* Additional Bus Info */}
            <div className="px-4 pb-4 grid grid-cols-3 gap-2">
              <div className="bg-slate-50 dark:bg-slate-800/50 p-2 rounded-xl border border-slate-100 dark:border-slate-800">
                <p className="text-[8px] text-slate-400 uppercase font-bold">Model</p>
                <p className="text-[10px] font-bold truncate">{busData.busModel}</p>
              </div>
              <div className="bg-slate-50 dark:bg-slate-800/50 p-2 rounded-xl border border-slate-100 dark:border-slate-800">
                <p className="text-[8px] text-slate-400 uppercase font-bold">Fuel</p>
                <p className="text-[10px] font-bold text-emerald-500">{busData.fuelType}</p>
              </div>
              <div className="bg-slate-50 dark:bg-slate-800/50 p-2 rounded-xl border border-slate-100 dark:border-slate-800">
                <p className="text-[8px] text-slate-400 uppercase font-bold">Temp</p>
                <p className="text-[10px] font-bold">{busData.temp}°C</p>
              </div>
            </div>
          </div>
        </motion.div>
      </main>

      {/* Bottom Nav */}
      <nav className="flex items-center bg-white dark:bg-background-dark px-6 py-3 border-t border-slate-200 dark:border-slate-800 z-30">
        <button onClick={() => onNavigate('home')} className="flex flex-1 flex-col items-center gap-1 text-slate-400">
          <Home className="size-6" />
          <span className="text-[10px] font-bold">Home</span>
        </button>
        <button onClick={() => onNavigate('tracking')} className="flex flex-1 flex-col items-center gap-1 text-primary">
          <Navigation className="size-6" style={{ fontVariationSettings: "'FILL' 1" }} />
          <span className="text-[10px] font-bold">Track</span>
        </button>
        <button onClick={() => onNavigate('tickets')} className="flex flex-1 flex-col items-center gap-1 text-slate-400">
          <Ticket className="size-6" />
          <span className="text-[10px] font-bold">Pass</span>
        </button>
        <button onClick={() => onNavigate('profile')} className="flex flex-col items-center gap-1 text-slate-400">
          <User className="size-6" />
          <span className="text-[10px] font-bold">Account</span>
        </button>
      </nav>
    </div>
  );
}
