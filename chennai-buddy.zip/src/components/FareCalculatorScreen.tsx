import { ArrowLeft, Locate, MapPin, Bus, Zap, Star, Snowflake, Calculator, Home, Ticket, User, Info } from 'lucide-react';
import { Screen } from '../types';

interface FareCalculatorScreenProps {
  onBack: () => void;
  onNavigate: (screen: Screen) => void;
}

export default function FareCalculatorScreen({ onBack, onNavigate }: FareCalculatorScreenProps) {
  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-background-dark">
      {/* Header */}
      <div className="flex items-center bg-background-light dark:bg-background-dark p-4 pb-2 sticky top-0 z-10 border-b border-slate-200 dark:border-slate-800">
        <button 
          onClick={onBack}
          className="text-slate-900 dark:text-slate-100 flex size-10 items-center justify-center cursor-pointer hover:bg-slate-100 rounded-full"
        >
          <ArrowLeft className="size-6" />
        </button>
        <h1 className="text-slate-900 dark:text-slate-100 text-lg font-bold leading-tight flex-1 text-center pr-10">Fare Calculator</h1>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto pb-24">
        {/* Hero */}
        <div className="px-4 py-4">
          <div className="w-full h-32 rounded-xl bg-primary/10 flex items-center justify-center overflow-hidden relative">
            <img 
              className="w-full h-full object-cover opacity-40" 
              alt="Minimalist map view of Chennai city streets" 
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuCuv8F9Y_ibPmVOySN5z0Ju4gId5XrsiFy4RtbPu1Tu2HvcyE-o8prE1ruw2-MS4SVwMhznhkjEQ0gaUTW_ud6Uj9F1pxSl3QuEZmq9uQn1_JmZLjkXfAZJ6aRafHZsb8wKCAm1_wCNiQiOt5Ukkc22KyRF-jrrW6reqyqgx_G63nGxriQXXEXauENeQkmZHvIiI6rg0Mt4hNvN1ruTxuLaMBBcchFvcXnl2VcRV1918QIM4YK6M6FRxlfjSHgBUyRa4kMN19bPXfFl"
            />
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <Bus className="text-primary size-10" />
              <p className="text-primary font-semibold text-sm mt-1">Chennai MTC Network</p>
            </div>
          </div>
        </div>

        {/* Form */}
        <div className="px-4 space-y-4">
          <h2 className="text-slate-900 dark:text-slate-100 text-xl font-bold tracking-tight">Route Details</h2>
          
          <div className="flex flex-col gap-2">
            <label className="text-slate-700 dark:text-slate-300 text-sm font-medium">Starting Point</label>
            <div className="flex w-full items-stretch rounded-lg group">
              <input 
                className="flex-1 rounded-l-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-4 py-3 text-base focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all" 
                placeholder="e.g., T. Nagar" 
                type="text" 
                defaultValue="Adyar Depot"
              />
              <div className="flex items-center justify-center px-3 rounded-r-lg border-y border-r border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800">
                <Locate className="text-slate-500 size-5" />
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-slate-700 dark:text-slate-300 text-sm font-medium">Destination</label>
            <div className="flex w-full items-stretch rounded-lg">
              <input 
                className="flex-1 rounded-l-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-4 py-3 text-base focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all" 
                placeholder="e.g., Tambaram" 
                type="text" 
                defaultValue="Broadway"
              />
              <div className="flex items-center justify-center px-3 rounded-r-lg border-y border-r border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800">
                <MapPin className="text-slate-500 size-5" />
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-slate-700 dark:text-slate-300 text-sm font-medium">Bus Type</label>
            <div className="grid grid-cols-2 gap-2">
              <button className="flex items-center justify-center gap-2 p-3 rounded-lg border-2 border-primary bg-primary/5 text-primary font-semibold">
                <Bus className="size-4" /> Normal
              </button>
              <button className="flex items-center justify-center gap-2 p-3 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400">
                <Zap className="size-4" /> Express
              </button>
              <button className="flex items-center justify-center gap-2 p-3 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400">
                <Star className="size-4" /> Deluxe
              </button>
              <button className="flex items-center justify-center gap-2 p-3 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400">
                <Snowflake className="size-4" /> AC
              </button>
            </div>
          </div>
        </div>

        {/* Fare Card */}
        <div className="px-4 mt-8">
          <div className="bg-primary rounded-xl p-6 text-white text-center shadow-lg shadow-primary/20">
            <p className="text-primary-foreground/80 text-sm font-medium mb-1">Estimated Fare</p>
            <div className="flex items-center justify-center gap-1">
              <span className="text-2xl font-bold">₹</span>
              <span className="text-5xl font-extrabold tracking-tight">18.00</span>
            </div>
            <p className="mt-2 text-xs opacity-80">Based on 12 MTC stages</p>
          </div>
        </div>

        {/* Breakdown */}
        <div className="px-4 mt-6">
          <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800">
            <h3 className="text-slate-900 dark:text-slate-100 font-bold mb-3 flex items-center gap-2">
              <Info className="text-primary size-5" />
              Calculation Details
            </h3>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Base Fare (0-2 km)</span>
                <span className="font-medium">₹5.00</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Distance Add-on (10 km)</span>
                <span className="font-medium">₹12.00</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Passenger Insurance</span>
                <span className="font-medium">₹1.00</span>
              </div>
              <div className="border-t border-slate-100 dark:border-slate-800 pt-3 flex justify-between font-bold text-base">
                <span>Total Fare</span>
                <span className="text-primary">₹18.00</span>
              </div>
            </div>
          </div>
        </div>

        {/* Action */}
        <div className="px-4 mt-8">
          <button 
            onClick={() => onNavigate('search_results')}
            className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-4 rounded-xl shadow-md transition-colors flex items-center justify-center gap-2 active:scale-[0.98]"
          >
            <Ticket className="size-5" />
            Book This Route
          </button>
        </div>
      </div>

      {/* Bottom Nav */}
      <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white/95 dark:bg-slate-950/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 pb-8">
        <div className="flex gap-2 px-4 pb-3 pt-2">
          <button onClick={() => onNavigate('home')} className="flex flex-1 flex-col items-center justify-center gap-1 text-slate-500 dark:text-slate-400">
            <Home className="size-6" />
            <p className="text-[10px] font-medium leading-normal">Home</p>
          </button>
          <button onClick={() => onNavigate('fare_calculator')} className="flex flex-1 flex-col items-center justify-center gap-1 text-primary">
            <Calculator className="size-6" style={{ fontVariationSettings: "'FILL' 1" }} />
            <p className="text-[10px] font-medium leading-normal">Calculator</p>
          </button>
          <button onClick={() => onNavigate('pass_selection')} className="flex flex-1 flex-col items-center justify-center gap-1 text-slate-500 dark:text-slate-400">
            <Ticket className="size-6" />
            <p className="text-[10px] font-medium leading-normal">Passes</p>
          </button>
          <button onClick={() => onNavigate('profile')} className="flex flex-1 flex-col items-center justify-center gap-1 text-slate-500 dark:text-slate-400">
            <User className="size-6" />
            <p className="text-[10px] font-medium leading-normal">Profile</p>
          </button>
        </div>
      </div>
    </div>
  );
}
