import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Screen } from './types';

// Components (to be implemented)
import LoginScreen from './components/LoginScreen';
import HomeScreen from './components/HomeScreen';
import SearchResultsScreen from './components/SearchResultsScreen';
import ConfirmBookingScreen from './components/ConfirmBookingScreen';
import TicketsScreen from './components/TicketsScreen';
import ProfileScreen from './components/ProfileScreen';
import TrackingScreen from './components/TrackingScreen';
import AdminDashboard from './components/AdminDashboard';
import FareCalculatorScreen from './components/FareCalculatorScreen';
import PassSelectionScreen from './components/PassSelectionScreen';
import PassActivationSuccessScreen from './components/PassActivationSuccessScreen';

import PassDetailsScreen from './components/PassDetailsScreen';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('login');

  const renderScreen = () => {
    switch (currentScreen) {
      case 'login':
        return <LoginScreen onLogin={() => setCurrentScreen('home')} />;
      case 'home':
        return <HomeScreen onNavigate={setCurrentScreen} />;
      case 'search_results':
        return <SearchResultsScreen onBack={() => setCurrentScreen('home')} onBook={() => setCurrentScreen('confirm_booking')} />;
      case 'confirm_booking':
        return <ConfirmBookingScreen onBack={() => setCurrentScreen('search_results')} onConfirm={() => setCurrentScreen('tickets')} />;
      case 'tickets':
        return <TicketsScreen onNavigate={setCurrentScreen} />;
      case 'profile':
        return <ProfileScreen onNavigate={setCurrentScreen} />;
      case 'tracking':
        return <TrackingScreen onBack={() => setCurrentScreen('home')} onNavigate={setCurrentScreen} />;
      case 'admin':
        return <AdminDashboard onNavigate={setCurrentScreen} />;
      case 'fare_calculator':
        return <FareCalculatorScreen onBack={() => setCurrentScreen('home')} onNavigate={setCurrentScreen} />;
      case 'pass_selection':
        return <PassSelectionScreen onBack={() => setCurrentScreen('home')} onSelect={() => setCurrentScreen('pass_details')} />;
      case 'pass_details':
        return <PassDetailsScreen onBack={() => setCurrentScreen('pass_selection')} onActivate={() => setCurrentScreen('pass_activation_success')} />;
      case 'pass_activation_success':
        return <PassActivationSuccessScreen onDone={() => setCurrentScreen('home')} onNavigate={setCurrentScreen} />;
      default:
        return <HomeScreen onNavigate={setCurrentScreen} />;
    }
  };

  return (
    <div className="min-h-screen bg-background-light dark:bg-background-dark font-display text-slate-900 dark:text-slate-100 selection:bg-primary/20">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentScreen}
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 1.05, y: -10 }}
          transition={{ 
            type: "spring",
            stiffness: 300,
            damping: 25
          }}
          className="max-w-md mx-auto min-h-screen bg-white dark:bg-slate-950 shadow-2xl relative overflow-hidden"
        >
          {renderScreen()}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
