import express from "express";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Google OAuth Configuration
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;

// Mock OTP Database
const otpStore = new Map<string, string>();

// API Routes
app.get("/api/auth/google/url", (req, res) => {
  const rootUrl = "https://accounts.google.com/o/oauth2/v2/auth";
  const options = {
    redirect_uri: `${process.env.APP_URL || 'http://localhost:3000'}/auth/callback`,
    client_id: GOOGLE_CLIENT_ID || "YOUR_GOOGLE_CLIENT_ID",
    access_type: "offline",
    response_type: "code",
    prompt: "consent",
    scope: [
      "https://www.googleapis.com/auth/userinfo.profile",
      "https://www.googleapis.com/auth/userinfo.email",
    ].join(" "),
  };

  const qs = new URLSearchParams(options);
  res.json({ url: `${rootUrl}?${qs.toString()}` });
});

app.get("/auth/callback", async (req, res) => {
  const code = req.query.code as string;

  if (!code) {
    return res.status(400).send("No code provided");
  }

  // In a real app, you would exchange the code for tokens here
  // For this demo, we'll just send a success message back to the popup
  
  res.send(`
    <html>
      <body>
        <script>
          if (window.opener) {
            window.opener.postMessage({ type: 'OAUTH_AUTH_SUCCESS', provider: 'google' }, '*');
            window.close();
          } else {
            window.location.href = '/';
          }
        </script>
        <p>Authentication successful. This window should close automatically.</p>
      </body>
    </html>
  `);
});

// OTP Routes
app.post("/api/auth/otp/send", (req, res) => {
  const { phone } = req.body;
  if (!phone) return res.status(400).json({ error: "Phone number required" });

  // For demo purposes, we'll use a fixed OTP or log it
  const otp = "123456"; 
  otpStore.set(phone, otp);
  
  console.log(`\n-----------------------------------------`);
  console.log(`[CHENNAI BUDDY] OTP for ${phone}: ${otp}`);
  console.log(`-----------------------------------------\n`);
  
  // Simulate network delay
  setTimeout(() => {
    res.json({ success: true, message: "OTP sent successfully! (Check terminal logs for the code)" });
  }, 1000);
});

app.post("/api/auth/otp/verify", (req, res) => {
  const { phone, otp } = req.body;
  const storedOtp = otpStore.get(phone);

  if (storedOtp && storedOtp === otp) {
    otpStore.delete(phone);
    res.json({ success: true, user: { phone, name: "User " + phone.slice(-4) } });
  } else {
    res.status(400).json({ error: "Invalid OTP" });
  }
});

// Vite middleware for development
if (process.env.NODE_ENV !== "production") {
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: "spa",
  });
  app.use(vite.middlewares);
} else {
  app.use(express.static("dist"));
  app.get("*", (req, res) => {
    res.sendFile("dist/index.html", { root: "." });
  });
}

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
